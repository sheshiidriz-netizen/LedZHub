/**
 * Motion tokens (taste-skill discipline):
 * one UI ease, one entrance ease, one travel ease — no overshoot.
 */
export const EASE: [number, number, number, number] = [0.2, 0.8, 0.2, 1];
export const EASE_ENTER: [number, number, number, number] = [0.22, 1, 0.36, 1];
export const EASE_TRAVEL: [number, number, number, number] = [0.65, 0, 0.35, 1];

export const DURATION = {
  hoverIn: 0.15,
  hoverOut: 0.12,
  press: 0.09,
  panel: 0.2,
  slide: 0.24,
  page: 0.62,
  entrance: 0.52,
  mask: 0.7,
} as const;
