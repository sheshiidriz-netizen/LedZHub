/**
 * Script lifecycle statuses and extra badges, shared by the hub UI,
 * the admin panel, and the API validation layer. One source of truth
 * so a badge can never disagree with the database.
 */
export const SCRIPT_STATUSES = [
  "working",
  "in_progress",
  "patched",
  "not_working",
] as const;

export type ScriptStatus = (typeof SCRIPT_STATUSES)[number];

export function isScriptStatus(v: unknown): v is ScriptStatus {
  return (
    typeof v === "string" &&
    (SCRIPT_STATUSES as readonly string[]).includes(v)
  );
}

export interface StatusMeta {
  label: string;
  /** Short label for tight spaces */
  short: string;
  /** Tailwind text color class */
  text: string;
  /** Tailwind border color class */
  border: string;
  /** Tailwind background tint */
  bg: string;
  /** Phosphor icon name, resolved by the caller (keeps this file UI-free) */
  icon: "seal-check" | "wrench" | "band-aids" | "prohibit";
}

export const STATUS_META: Record<ScriptStatus, StatusMeta> = {
  working: {
    label: "Working",
    short: "Working",
    text: "text-emerald-300",
    border: "border-emerald-500/30",
    bg: "bg-emerald-500/10",
    icon: "seal-check",
  },
  in_progress: {
    label: "Working on it",
    short: "WIP",
    text: "text-sky-300",
    border: "border-sky-500/30",
    bg: "bg-sky-500/10",
    icon: "wrench",
  },
  patched: {
    label: "Patched",
    short: "Patched",
    text: "text-amber-300",
    border: "border-amber-500/30",
    bg: "bg-amber-500/10",
    icon: "band-aids",
  },
  not_working: {
    label: "Not working",
    short: "Down",
    text: "text-red-300",
    border: "border-red-500/30",
    bg: "bg-red-500/10",
    icon: "prohibit",
  },
};

/* ── Extra badges ─────────────────────────────────────────────
 * Attribute pills an admin can stack on any script next to its
 * status: pricing and key requirements. Kept as a fixed catalog so
 * the API can validate them and the UI can style them consistently. */

export const SCRIPT_BADGES = ["paid", "keyless", "key_system"] as const;

export type ScriptBadge = (typeof SCRIPT_BADGES)[number];

export function isScriptBadge(v: unknown): v is ScriptBadge {
  return (
    typeof v === "string" &&
    (SCRIPT_BADGES as readonly string[]).includes(v)
  );
}

/** Keep only known badges, de-duplicated, in catalog order. */
export function sanitizeBadges(v: unknown): ScriptBadge[] {
  if (!Array.isArray(v)) return [];
  const seen = new Set<ScriptBadge>();
  for (const id of SCRIPT_BADGES) {
    if (v.includes(id)) seen.add(id);
  }
  return SCRIPT_BADGES.filter((id) => seen.has(id));
}

export interface BadgeMeta {
  label: string;
  /** Tailwind text color class */
  text: string;
  /** Tailwind border color class */
  border: string;
  /** Tailwind background tint */
  bg: string;
  /** Phosphor icon name, resolved by the caller (keeps this file UI-free) */
  icon: "currency-circle-dollar" | "lock-open" | "key";
}

export const BADGE_META: Record<ScriptBadge, BadgeMeta> = {
  paid: {
    label: "Paid",
    text: "text-yellow-300",
    border: "border-yellow-500/30",
    bg: "bg-yellow-500/10",
    icon: "currency-circle-dollar",
  },
  keyless: {
    label: "Keyless",
    text: "text-emerald-300",
    border: "border-emerald-500/30",
    bg: "bg-emerald-500/10",
    icon: "lock-open",
  },
  key_system: {
    label: "Key System",
    text: "text-ledz",
    border: "border-ledz/30",
    bg: "bg-ledz/10",
    icon: "key",
  },
};
