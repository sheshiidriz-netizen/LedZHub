import { db } from "@/lib/db";

/**
 * Fixed-window rate limiter, persisted in the database.
 *
 * The window state lives in the `RateLimitWindow` table, so a page
 * refresh, a dev-server reload or a full restart can never hand out
 * extra attempts: the countdown the admin sees is the countdown the
 * server enforces. Keys are `${bucket}:${ip}` so one endpoint cannot
 * starve another.
 *
 * On a database failure the limiter fails OPEN: the hub stays usable
 * and only the brute-force throttle is lost (sessions and data are
 * unaffected).
 */

export interface RateLimitResult {
  ok: boolean;
  remaining: number;
  retryAfterSec: number;
}

/** Bump the counter for this bucket+ip and decide. */
export async function rateLimit(
  bucket: string,
  ip: string,
  limit: number,
  windowMs: number
): Promise<RateLimitResult> {
  const key = `${bucket}:${ip}`;
  const now = Date.now();

  try {
    // Atomic bump for any window that is still open and below the cap.
    const bumped = await db.rateLimitWindow.updateMany({
      where: { key, resetAt: { gt: new Date(now) }, count: { lt: limit } },
      data: { count: { increment: 1 } },
    });

    if (bumped.count === 1) {
      const row = await db.rateLimitWindow.findUnique({
        where: { key },
        select: { count: true },
      });
      const count = row?.count ?? 1;
      return {
        ok: true,
        remaining: Math.max(0, limit - count),
        retryAfterSec: 0,
      };
    }

    // No bump: the window is missing, expired, or already at the cap.
    const row = await db.rateLimitWindow.findUnique({ where: { key } });

    if (row && row.resetAt.getTime() > now) {
      // Still inside an exhausted window: blocked.
      return {
        ok: false,
        remaining: 0,
        retryAfterSec: Math.max(1, Math.ceil((row.resetAt.getTime() - now) / 1000)),
      };
    }

    // Expired or first-ever hit: open a fresh window.
    await db.rateLimitWindow.upsert({
      where: { key },
      create: { key, count: 1, resetAt: new Date(now + windowMs) },
      update: { count: 1, resetAt: new Date(now + windowMs) },
    });
    return { ok: true, remaining: limit - 1, retryAfterSec: 0 };
  } catch {
    // Database unavailable: fail open, the hub stays usable.
    return { ok: true, remaining: limit, retryAfterSec: 0 };
  } finally {
    void sweepExpired();
  }
}

/** Seconds left on this bucket's lock (0 when free). Only an exhausted
 *  window counts: a partially used window must never look locked, or
 *  every refresh would disable the buttons after one ordinary request. */
export async function peekRateLimit(
  bucket: string,
  ip: string,
  limit: number
): Promise<number> {
  try {
    const row = await db.rateLimitWindow.findUnique({
      where: { key: `${bucket}:${ip}` },
      select: { count: true, resetAt: true },
    });
    if (!row || row.count < limit) return 0;
    const ms = row.resetAt.getTime() - Date.now();
    return ms > 0 ? Math.ceil(ms / 1000) : 0;
  } catch {
    return 0;
  }
}

/** Opportunistic cleanup of expired windows; never blocks the caller. */
async function sweepExpired(): Promise<void> {
  try {
    await db.rateLimitWindow.deleteMany({
      where: { resetAt: { lt: new Date() } },
    });
  } catch {
    /* swept away on a later request */
  }
}

/** Client IP behind the edge proxy, best effort. */
export function clientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return req.headers.get("x-real-ip") ?? "unknown";
}
