import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hasAdminSession, isSameOrigin } from "@/lib/admin-auth";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { isScriptStatus, sanitizeBadges, type ScriptBadge } from "@/lib/script-status";
import type { HubScript } from "@/lib/hub-data";

/** DB row -> public API shape (status and badges stay honest). */
export function toHub(row: {
  id: string;
  title: string;
  category: string;
  code: string;
  status: string;
  badges?: string | null;
}): HubScript {
  let badges: ScriptBadge[] = [];
  if (typeof row.badges === "string") {
    try {
      badges = sanitizeBadges(JSON.parse(row.badges));
    } catch {
      badges = [];
    }
  }
  return {
    id: row.id,
    title: row.title,
    category: row.category,
    code: row.code,
    status: isScriptStatus(row.status) ? row.status : "working",
    badges,
  };
}

/**
 * Guard for every admin route: valid session, same-origin request,
 * and a 30/min rate limit per IP (persisted in the DB, so a refresh
 * never resets it). Returns a Response when denied.
 */
export async function guardAdmin(
  req: Request,
  bucket: string,
  limit = 30
): Promise<NextResponse | null> {
  if (!hasAdminSession(req)) {
    return NextResponse.json({ error: "Not authorized." }, { status: 401 });
  }
  if (!isSameOrigin(req)) {
    return NextResponse.json(
      { error: "Cross-origin request blocked." },
      { status: 403 }
    );
  }
  const rl = await rateLimit(bucket, clientIp(req), limit, 60 * 1000);
  if (!rl.ok) {
    return NextResponse.json(
      {
        error: `Too many actions. Try again in ${rl.retryAfterSec}s.`,
        retryAfter: rl.retryAfterSec,
      },
      { status: 429, headers: { "retry-after": String(rl.retryAfterSec) } }
    );
  }
  return null;
}
