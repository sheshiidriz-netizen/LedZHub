import { createHmac, randomBytes, timingSafeEqual, createHash } from "crypto";

/**
 * Admin session tokens: `${expiry}.${nonce}.${hmac}`.
 *
 * Stateless and signed: the server only needs LEDZ_SESSION_SECRET to
 * verify. Tampering with the expiry or the nonce breaks the HMAC, and
 * the HMAC is compared with a constant-time equal, so an attacker
 * learns nothing from response timing.
 */

export const ADMIN_COOKIE = "ledz_admin";
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours

function secret(): string {
  const s = process.env.LEDZ_SESSION_SECRET;
  if (!s || s.length < 16) {
    throw new Error("LEDZ_SESSION_SECRET is missing or too short");
  }
  return s;
}

export function createSessionToken(): string {
  const exp = Date.now() + SESSION_TTL_MS;
  const nonce = randomBytes(12).toString("hex");
  const payload = `${exp}.${nonce}`;
  const sig = createHmac("sha256", secret()).update(payload).digest("hex");
  return `${payload}.${sig}`;
}

export function verifySessionToken(token: string | undefined): boolean {
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [expRaw, nonce, sig] = parts;

  const exp = Number(expRaw);
  if (!Number.isInteger(exp) || exp < Date.now()) return false;
  if (!/^[a-f0-9]{24}$/.test(nonce) || !/^[a-f0-9]{64}$/.test(sig)) return false;

  const expected = createHmac("sha256", secret())
    .update(`${expRaw}.${nonce}`)
    .digest("hex");

  const a = Buffer.from(sig, "hex");
  const b = Buffer.from(expected, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

/** Constant-time password check: hash first so length never leaks. */
export function verifyAdminPassword(input: unknown): boolean {
  if (typeof input !== "string" || input.length === 0 || input.length > 200) {
    return false;
  }
  const expected = process.env.LEDZ_ADMIN_PASSWORD;
  if (!expected) return false;

  const a = createHash("sha256").update(input).digest();
  const b = createHash("sha256").update(expected).digest();
  return timingSafeEqual(a, b);
}

/**
 * Same-origin guard for state-changing routes. Blocks cross-site
 * requests even if a session cookie somehow rides along (CSRF).
 */
export function isSameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");

  // Non-browser clients (curl, tests) send no Origin: allowed, the
  // cookie still has to be valid. Browsers always send Origin on POST.
  if (!origin) {
    const site = req.headers.get("sec-fetch-site");
    if (site && site !== "same-origin" && site !== "none") return false;
    return true;
  }

  const host =
    req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  if (!host) return false;

  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

/** Reads the admin cookie from a Request (route handler flavor). */
export function hasAdminSession(req: Request): boolean {
  const cookieHeader = req.headers.get("cookie");
  if (!cookieHeader) return false;

  for (const part of cookieHeader.split(";")) {
    const [name, ...rest] = part.trim().split("=");
    if (name === ADMIN_COOKIE) {
      return verifySessionToken(decodeURIComponent(rest.join("=")));
    }
  }
  return false;
}
