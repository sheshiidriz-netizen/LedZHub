"use client";

import { useEffect, useState } from "react";

/** Debounce a fast-changing value (search typing) for server calls. */
export function useDebouncedValue<T>(value: T, ms = 120): T {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);

  return debounced;
}
