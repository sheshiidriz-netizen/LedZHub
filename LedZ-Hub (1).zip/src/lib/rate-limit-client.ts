"use client";

import { useEffect, useState } from "react";

/**
 * Shared rate-limit lock for the admin panel.
 *
 * Every 429 with a `retryAfter` seconds value reports here, and every
 * rate-limited button (login, publish, save, delete) counts down from
 * the SAME server-issued deadline. When it hits zero the buttons
 * unlock on their own - no refresh needed, and a refresh cannot cheat
 * it because the server keeps the real window.
 */

let lockUntil = 0;
const listeners = new Set<() => void>();

export function reportLockSeconds(sec: number): void {
  const s = Number.isFinite(sec) ? Math.max(1, Math.round(sec)) : 30;
  const until = Date.now() + s * 1000;
  if (until > lockUntil) {
    lockUntil = until;
    for (const l of listeners) l();
  }
}

function remaining(): number {
  return Math.max(0, Math.ceil((lockUntil - Date.now()) / 1000));
}

/** Live countdown in seconds; ticks four times a second while locked. */
export function useLockSeconds(): number {
  const [sec, setSec] = useState(remaining);

  useEffect(() => {
    const update = () => setSec(remaining());
    update();
    listeners.add(update);
    const iv = setInterval(update, 250);
    return () => {
      listeners.delete(update);
      clearInterval(iv);
    };
  }, []);

  return sec;
}
