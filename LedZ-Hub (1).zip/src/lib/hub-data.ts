/**
 * LedZ Hub, Void Edition
 * Contract shared by the hub UI, the admin panel, and the API layer.
 * The database (Prisma) is the source of truth once scripts are
 * seeded; this embedded list is the offline fallback only.
 */

import type { ScriptBadge, ScriptStatus } from "./script-status";

export type { ScriptBadge, ScriptStatus };

export interface HubScript {
  id: string;
  title: string;
  category: string;
  code: string;
  status: ScriptStatus;
  /** Attribute pills: paid, keyless, key_system. Always a real subset
   *  of the catalog, never free text, so the UI can trust it. */
  badges: ScriptBadge[];
}

export interface ScriptsResponse {
  source: "rust-core" | "next-runtime";
  total: number;
  generated_at: string;
  scripts: HubScript[];
}

export interface KeyResponse {
  source: "rust-core" | "next-runtime";
  label: string;
  key: string;
  status: string;
  active: boolean;
  updated_at: string;
}

const WORKING = "working" as const;

/** Every script in the hub unlocks through the universal LedZ key,
 * exactly as the Key System tab describes, so the fallback list says so. */
const KEYED: ScriptBadge[] = ["key_system"];

export const SCRIPTS: HubScript[] = [
  {
    id: "naval-warfare",
    title: "Naval Warfare",
    category: "Combat",
    status: WORKING,
    badges: KEYED,
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/navalwarfareLedZ/main/navalwarfere"))()`,
  },
  {
    id: "ninja-legends",
    title: "Ninja Legends",
    category: "Farming",
    status: WORKING,
    badges: KEYED,
    code: `pcall(loadstring(game:HttpGet("https://raw.githubusercontent.com/sheshiidriz-netizen/NinjaLegends-/main/InfMoney")))`,
  },
  {
    id: "mvsd",
    title: "Murderers VS Sheriffs DUELS",
    category: "PvP",
    status: WORKING,
    badges: KEYED,
    code: `pcall(loadstring(game:HttpGet("https://raw.githubusercontent.com/sheshiidriz-netizen/LEDZ/main/MvsD")))`,
  },
  {
    id: "fight-in-a-prison",
    title: "Fight In A Prison",
    category: "Action",
    status: WORKING,
    badges: KEYED,
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/fightinaprison/refs/heads/main/ledzfightinaprison"))()`,
  },
  {
    id: "age-evolution-tycoon",
    title: "Age Evolution Tycoon",
    category: "Tycoon",
    status: WORKING,
    badges: KEYED,
    code: `pcall(loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/AgeEvelutionTycoon/main/AgeEvelutionTycoon")))`,
  },
  {
    id: "millionaire-tycoon",
    title: "Millionaire Tycoon",
    category: "Tycoon",
    status: WORKING,
    badges: KEYED,
    code: `pcall(loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/MillonareTycoon/main/Tycoon")))`,
  },
  {
    id: "blox-strike",
    title: "Blox Strike",
    category: "FPS",
    status: WORKING,
    badges: KEYED,
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/bloxstrike/refs/heads/main/ledz"))()`,
  },
  {
    id: "mm2-premium",
    title: "Murder Mystery 2 Premium",
    category: "Survival",
    status: WORKING,
    badges: KEYED,
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/murdermystery2/refs/heads/main/LedZPremium"))()`,
  },
  {
    id: "find-the-needle",
    title: "Find The Needle",
    category: "Casual",
    status: WORKING,
    badges: KEYED,
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/findtheneedle/refs/heads/main/ledz"))()`,
  },
  {
    id: "soccer-touch-football",
    title: "Soccer Touch Football",
    category: "Sports",
    status: WORKING,
    badges: KEYED,
    code: `loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/soccertouchfootball/refs/heads/main/ledz"))()`,
  },
];

export const KEY_INFO = {
  label: "Global Script Key",
  key: "LedZKey",
  status: "Verified Universal Access",
  active: true,
};

export function filterScripts(list: HubScript[], query: string): HubScript[] {
  const q = query.trim().toLowerCase();
  if (!q) return list;
  return list.filter(
    (s) =>
      s.title.toLowerCase().includes(q) ||
      s.category.toLowerCase().includes(q)
  );
}

/**
 * Ranked suggestions for the search dropdown. Best match first:
 * title prefix, title word prefix, title acronym (so "mm2" finds
 * "Murder Mystery 2"), title substring, then category. Same order
 * the Rust core implements for its own endpoint.
 */
export function rankScripts(
  list: HubScript[],
  query: string,
  limit = 8
): HubScript[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];

  const scored: { script: HubScript; score: number }[] = [];
  for (const script of list) {
    const title = script.title.toLowerCase();
    const category = script.category.toLowerCase();
    let score = -1;
    if (title.startsWith(q)) score = 0;
    else if (title.split(/\s+/).some((w) => w.startsWith(q))) score = 1;
    else if (
      q.length >= 2 &&
      script.title
        .split(/\s+/)
        .map((w) => w.charAt(0).toLowerCase())
        .join("")
        .startsWith(q)
    )
      score = 2;
    else if (title.includes(q)) score = 3;
    else if (category.startsWith(q)) score = 4;
    else if (category.includes(q)) score = 5;
    if (score >= 0) scored.push({ script, score });
  }

  scored.sort(
    (a, b) => a.score - b.score || a.script.title.localeCompare(b.script.title)
  );
  return scored.slice(0, limit).map((x) => x.script);
}

export function countCategories(list: HubScript[]): number {
  return new Set(list.map((s) => s.category)).size;
}
