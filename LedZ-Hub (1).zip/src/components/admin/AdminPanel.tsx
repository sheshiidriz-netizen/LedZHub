"use client";

import {
  useCallback,
  useEffect,
  useState,
  type FormEvent,
} from "react";
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Password,
  SignIn,
  SignOut,
  Plus,
  TrashSimple,
  PencilSimple,
  Check,
  X,
  ArrowLeft,
  FloppyDisk,
  WarningCircle,
} from "@phosphor-icons/react";
import { ZMark } from "@/components/hub/ZLogo";
import { StatusBadge, BadgePill, BADGE_ICONS } from "@/components/hub/ScriptCard";
import {
  reportLockSeconds,
  useLockSeconds,
} from "@/lib/rate-limit-client";
import {
  SCRIPT_STATUSES,
  STATUS_META,
  SCRIPT_BADGES,
  BADGE_META,
  type ScriptBadge,
  type ScriptStatus,
} from "@/lib/script-status";
import type { HubScript, ScriptsResponse } from "@/lib/hub-data";

/* ────────────────────────── API plumbing ────────────────────────── */

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "content-type": "application/json", ...(init?.headers ?? {}) },
  });
  const body = (await res.json().catch(() => ({}))) as Record<string, unknown>;

  if (!res.ok) {
    const retryAfter =
      Number(body.retryAfter ?? 0) ||
      Number(res.headers.get("retry-after") ?? 0);
    // One shared countdown: every rate-limited button locks and
    // unlocks together, on the server's schedule.
    if (res.status === 429 && retryAfter > 0) {
      reportLockSeconds(retryAfter);
    }
    const err = new Error(
      (body.error as string) ?? `Request failed (${res.status}).`
    );
    (err as Error & { status?: number; retryAfter?: number }).status = res.status;
    (err as Error & { status?: number; retryAfter?: number }).retryAfter =
      retryAfter;
    throw err;
  }
  return body as T;
}

/** Cross-tab ping: every open hub tab listens for this key and
 *  refetches the live script counter the moment a script is added,
 *  edited or removed here. */
function broadcastScriptsChange() {
  try {
    window.localStorage.setItem("ledz-scripts-rev", String(Date.now()));
  } catch {
    /* storage blocked: hub tabs still refresh on window focus */
  }
}

const adminScriptsKey = ["admin-scripts"] as const;

/* ────────────────────────── Login gate ────────────────────────── */

function LoginGate({ onAuthed }: { onAuthed: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  /* Live countdown, shared with every other admin button. Seeded
     straight from the server on refresh, so the lock survives reloads
     and the button unlocks the moment the window expires. */
  const locked = useLockSeconds();

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!password || submitting || locked > 0) return;
    setSubmitting(true);
    setError(null);
    try {
      await api("/api/admin/login", {
        method: "POST",
        body: JSON.stringify({ password }),
      });
      setPassword("");
      onAuthed();
    } catch (err) {
      const e2 = err as Error & { status?: number; retryAfter?: number };
      if (e2.status === 429) {
        setError("Too many attempts. The button unlocks when the countdown ends.");
      } else if (e2.status === 401) {
        setError("Wrong password. Check it and try again.");
      } else {
        setError(e2.message);
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="panel-frame box-glow-red w-full max-w-sm space-y-7 rounded-[24px] p-7">
        <div className="flex flex-col items-center gap-3 text-center">
          <span className="border-ledz/40 from-neutral-900 to-black flex h-14 w-14 items-center justify-center rounded-2xl border bg-gradient-to-b shadow-[0_0_24px_-6px_rgba(255,0,60,0.55)]">
            <ZMark size={30} />
          </span>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Admin access
          </h1>
          <p className="text-sm leading-relaxed text-neutral-400">
            Enter the admin password to manage the script hub.
          </p>
        </div>

        <form onSubmit={submit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <label
              htmlFor="admin-password"
              className="block font-mono text-[11px] font-bold tracking-[0.2em] text-neutral-300 uppercase"
            >
              Password
            </label>
            <div className="relative">
              <Password
                className="pointer-events-none absolute top-1/2 left-4 h-4 w-4 -translate-y-1/2 text-neutral-500"
                weight="bold"
                aria-hidden="true"
              />
              <input
                id="admin-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                autoFocus
                aria-invalid={error ? "true" : undefined}
                aria-describedby={error ? "login-error" : undefined}
                className="focus:border-ledz/70 focus:ring-ledz/40 h-12 w-full rounded-2xl border border-[#2b2b3a] bg-black/85 pr-4 pl-11 text-sm text-white transition-all duration-200 placeholder:text-neutral-500 focus:ring-2 focus:outline-none"
                placeholder="Admin password"
              />
            </div>
          </div>

          {error && (
            <p
              id="login-error"
              role="alert"
              className="flex items-start gap-2 rounded-xl border border-red-500/30 bg-red-500/10 px-3.5 py-2.5 text-xs leading-relaxed text-red-300"
            >
              <WarningCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" weight="bold" aria-hidden="true" />
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting || locked > 0 || !password}
            className="btn-primary btn-sheen flex h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-2xl text-sm font-bold tracking-[0.12em] uppercase disabled:cursor-not-allowed disabled:opacity-50"
          >
            <SignIn className="h-4 w-4" weight="bold" aria-hidden="true" />
            {locked > 0
              ? `Locked ${locked}s`
              : submitting
                ? "Checking..."
                : "Unlock admin"}
          </button>
        </form>

        <a
          href="/"
          className="flex items-center justify-center gap-1.5 font-mono text-[11px] font-semibold tracking-[0.15em] text-neutral-500 uppercase transition-colors duration-200 hover:text-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" weight="bold" aria-hidden="true" />
          Back to the hub
        </a>
      </div>
    </main>
  );
}

/* ────────────────────── Badge toggles ────────────────────── */

/** Multi-select badge chips: Paid, Keyless, Key System. The same
 *  catalog the API validates, so a toggle can never desync the DB. */
function BadgeToggles({
  value,
  onChange,
  idPrefix,
}: {
  value: ScriptBadge[];
  onChange: (next: ScriptBadge[]) => void;
  idPrefix: string;
}) {
  return (
    <div
      className="flex flex-wrap gap-2"
      role="group"
      aria-label="Script badges"
    >
      {SCRIPT_BADGES.map((b) => {
        const active = value.includes(b);
        const meta = BADGE_META[b];
        const Icon = BADGE_ICONS[b];
        return (
          <button
            key={b}
            type="button"
            id={`${idPrefix}-badge-${b}`}
            aria-pressed={active}
            onClick={() =>
              onChange(
                active ? value.filter((x) => x !== b) : [...value, b]
              )
            }
            className={`flex min-h-[44px] cursor-pointer items-center gap-2 rounded-xl border px-4 font-mono text-[11px] font-bold tracking-[0.12em] uppercase transition-colors duration-200 ${
              active
                ? `${meta.text} ${meta.border} ${meta.bg}`
                : "border-[#2b2b3a] bg-black/70 text-neutral-400 hover:border-ledz/50 hover:text-white"
            }`}
          >
            <Icon className="h-3.5 w-3.5" weight="bold" aria-hidden="true" />
            {meta.label}
          </button>
        );
      })}
    </div>
  );
}

/* ────────────────────────── Add form ────────────────────────── */

function AddScriptForm() {
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [code, setCode] = useState("");
  const [status, setStatus] = useState<ScriptStatus>("working");
  const [badges, setBadges] = useState<ScriptBadge[]>([]);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const locked = useLockSeconds();

  const create = useMutation({
    mutationFn: () =>
      api("/api/admin/scripts", {
        method: "POST",
        body: JSON.stringify({ title, code, category, status, badges }),
      }),
    onSuccess: () => {
      toast.success("Script added", {
        description: `${title.trim()} is live on the hub.`,
      });
      setTitle("");
      setCategory("");
      setCode("");
      setStatus("working");
      setBadges([]);
      setFieldErrors({});
      qc.invalidateQueries({ queryKey: adminScriptsKey });
      qc.invalidateQueries({ queryKey: ["ledz-scripts"] });
      broadcastScriptsChange();
    },
    onError: (err) => {
      const e2 = err as Error & { status?: number };
      toast.error("Could not add the script", { description: e2.message });
    },
  });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};
    if (title.trim().length < 2) errors.title = "Give it a real title.";
    if (code.trim().length < 4) errors.code = "The loadstring looks too short.";
    setFieldErrors(errors);
    if (Object.keys(errors).length === 0) create.mutate();
  };

  const inputCls =
    "h-11 w-full rounded-xl border border-[#2b2b3a] bg-black/70 px-3.5 text-sm text-white transition-all duration-200 placeholder:text-neutral-500 focus:border-ledz/70 focus:ring-ledz/40 focus:ring-2 focus:outline-none";
  const labelCls =
    "block font-mono text-[11px] font-bold tracking-[0.18em] text-neutral-300 uppercase";

  return (
    <form
      onSubmit={submit}
      noValidate
      className="card-wash border-ledz-border bg-void-raised/70 space-y-4 rounded-[22px] border p-6"
    >
      <h2 className="flex items-center gap-2.5 text-base font-bold text-white">
        <span className="border-ledz/40 text-ledz flex h-8 w-8 items-center justify-center rounded-xl border bg-black/60">
          <Plus className="h-4 w-4" weight="bold" aria-hidden="true" />
        </span>
        Add a script
      </h2>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <label htmlFor="new-title" className={labelCls}>
            Game title
          </label>
          <input
            id="new-title"
            className={inputCls}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Blox Fruits"
          />
          {fieldErrors.title && (
            <p role="alert" className="text-xs text-red-400">{fieldErrors.title}</p>
          )}
        </div>
        <div className="space-y-1.5">
          <label htmlFor="new-category" className={labelCls}>
            Category <span className="text-neutral-600 normal-case">(optional)</span>
          </label>
          <input
            id="new-category"
            className={inputCls}
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            placeholder="Farming"
          />
        </div>
      </div>

      <div className="space-y-1.5">
        <label htmlFor="new-code" className={labelCls}>
          Loadstring
        </label>
        <textarea
          id="new-code"
          className="min-h-[88px] w-full rounded-xl border border-[#2b2b3a] bg-black/70 p-3.5 font-mono text-[13px] leading-relaxed break-all text-ledz transition-all duration-200 placeholder:text-neutral-600 focus:border-ledz/70 focus:ring-ledz/40 focus:ring-2 focus:outline-none"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder='loadstring(game:HttpGet("https://..."))()'
        />
        {fieldErrors.code && (
          <p role="alert" className="text-xs text-red-400">{fieldErrors.code}</p>
        )}
      </div>

      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="space-y-4">
          <div className="space-y-1.5">
            <label htmlFor="new-status" className={labelCls}>
              Status
            </label>
            <select
              id="new-status"
              className={`${inputCls} cursor-pointer pr-9`}
              value={status}
              onChange={(e) => setStatus(e.target.value as ScriptStatus)}
            >
              {SCRIPT_STATUSES.map((s) => (
                <option key={s} value={s} className="bg-neutral-950">
                  {STATUS_META[s].label}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <span
              id="new-badges-label"
              className={`${labelCls} block`}
            >
              Badges{" "}
              <span className="text-neutral-600 normal-case">(optional)</span>
            </span>
            <BadgeToggles
              value={badges}
              onChange={setBadges}
              idPrefix="new"
            />
          </div>
        </div>
        <button
          type="submit"
          disabled={create.isPending || locked > 0}
          className="btn-primary btn-sheen flex h-11 cursor-pointer items-center gap-2 rounded-xl px-6 text-sm font-bold tracking-[0.1em] uppercase disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Plus className="h-4 w-4" weight="bold" aria-hidden="true" />
          {locked > 0
            ? `Locked ${locked}s`
            : create.isPending
              ? "Publishing..."
              : "Publish script"}
        </button>
      </div>
    </form>
  );
}

/* ────────────────────────── Script row ────────────────────────── */

function ScriptRow({ script }: { script: HubScript }) {
  const qc = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [title, setTitle] = useState(script.title);
  const [category, setCategory] = useState(script.category);
  const [code, setCode] = useState(script.code);
  const [status, setStatus] = useState<ScriptStatus>(script.status);
  const [badges, setBadges] = useState<ScriptBadge[]>(script.badges);
  const locked = useLockSeconds();

  /* Reset the edit fields to the latest server row whenever the prop
     changes while not editing (render-time adjustment per React docs). */
  const [seed, setSeed] = useState(script);
  if (!editing && seed !== script) {
    setSeed(script);
    setTitle(script.title);
    setCategory(script.category);
    setCode(script.code);
    setStatus(script.status);
    setBadges(script.badges);
  }

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: adminScriptsKey });
    qc.invalidateQueries({ queryKey: ["ledz-scripts"] });
    broadcastScriptsChange();
  };

  const patch = useMutation({
    mutationFn: (data: Record<string, unknown>) =>
      api(`/api/admin/scripts/${script.id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      }),
    onSuccess: () => invalidate(),
    onError: (err) =>
      toast.error("Update failed", {
        description: (err as Error).message,
      }),
  });

  const remove = useMutation({
    mutationFn: () =>
      api(`/api/admin/scripts/${script.id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success("Script removed", {
        description: `${script.title} is gone from the hub.`,
      });
      invalidate();
    },
    onError: (err) =>
      toast.error("Delete failed", { description: (err as Error).message }),
  });

  const busy = patch.isPending || remove.isPending;

  const saveEdit = () => {
    patch.mutate(
      {
        title: title.trim(),
        category: category.trim(),
        code: code.trim(),
        status,
        badges,
      },
      {
        onSuccess: () => {
          toast.success("Script updated", { description: title.trim() });
          setEditing(false);
        },
      }
    );
  };

  const inputCls =
    "h-10 w-full rounded-lg border border-[#2b2b3a] bg-black/70 px-3 text-sm text-white transition-all duration-200 focus:border-ledz/70 focus:ring-ledz/40 focus:ring-2 focus:outline-none";

  return (
    <li className="border-ledz-border/70 border-b last:border-b-0">
      <div className="flex flex-col gap-4 px-5 py-4 sm:flex-row sm:items-start">
        {/* Main info */}
        <div className="min-w-0 flex-1 space-y-2">
          {editing ? (
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <label className="block text-[11px] font-semibold text-neutral-400" htmlFor={`edit-title-${script.id}`}>
                  Title
                </label>
                <input
                  id={`edit-title-${script.id}`}
                  className={inputCls}
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <label className="block text-[11px] font-semibold text-neutral-400" htmlFor={`edit-cat-${script.id}`}>
                  Category
                </label>
                <input
                  id={`edit-cat-${script.id}`}
                  className={inputCls}
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                />
              </div>
              <div className="space-y-1 sm:col-span-2">
                <label className="block text-[11px] font-semibold text-neutral-400" htmlFor={`edit-code-${script.id}`}>
                  Loadstring
                </label>
                <textarea
                  id={`edit-code-${script.id}`}
                  className="min-h-[72px] w-full rounded-lg border border-[#2b2b3a] bg-black/70 p-3 font-mono text-xs leading-relaxed break-all text-ledz focus:border-ledz/70 focus:ring-ledz/40 focus:ring-2 focus:outline-none"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <span
                  id={`edit-badges-label-${script.id}`}
                  className="block text-[11px] font-semibold text-neutral-400"
                >
                  Badges
                </span>
                <BadgeToggles
                  value={badges}
                  onChange={setBadges}
                  idPrefix={`edit-${script.id}`}
                />
              </div>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="truncate text-[15px] font-bold text-white">
                  {script.title}
                </span>
                <StatusBadge status={script.status} size="sm" />
                {script.badges.map((b) => (
                  <BadgePill key={b} badge={b} size="sm" />
                ))}
              </div>
              <p className="truncate font-mono text-[11px] text-neutral-500">
                {script.category} · id {script.id}
              </p>
              <p className="truncate font-mono text-xs text-neutral-600">
                {script.code}
              </p>
            </>
          )}
        </div>

        {/* Controls */}
        <div className="flex shrink-0 flex-wrap items-center gap-2">
          {editing ? (
            <>
              <button
                type="button"
                onClick={saveEdit}
                disabled={busy || locked > 0}
                className="btn-primary flex h-10 cursor-pointer items-center gap-1.5 rounded-xl px-4 text-xs font-bold tracking-wide uppercase disabled:cursor-not-allowed disabled:opacity-50"
              >
                <FloppyDisk className="h-4 w-4" weight="bold" aria-hidden="true" />
                {locked > 0 ? `Locked ${locked}s` : "Save"}
              </button>
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="border-ledz-border text-neutral-300 hover:border-ledz/60 hover:text-white flex h-10 cursor-pointer items-center gap-1.5 rounded-xl border px-4 text-xs font-bold tracking-wide uppercase transition-colors duration-200"
              >
                <X className="h-4 w-4" weight="bold" aria-hidden="true" />
                Cancel
              </button>
            </>
          ) : confirmingDelete ? (
            <>
              <button
                type="button"
                onClick={() => remove.mutate()}
                disabled={busy || locked > 0}
                className="flex h-10 cursor-pointer items-center gap-1.5 rounded-xl border border-red-500/50 bg-red-500/15 px-4 text-xs font-bold tracking-wide text-red-300 uppercase transition-colors duration-200 hover:bg-red-500/25 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Check className="h-4 w-4" weight="bold" aria-hidden="true" />
                {locked > 0
                  ? `Locked ${locked}s`
                  : remove.isPending
                    ? "Removing..."
                    : "Confirm delete"}
              </button>
              <button
                type="button"
                onClick={() => setConfirmingDelete(false)}
                className="border-ledz-border text-neutral-300 hover:text-white flex h-10 cursor-pointer items-center gap-1.5 rounded-xl border px-4 text-xs font-bold tracking-wide uppercase transition-colors duration-200"
              >
                <X className="h-4 w-4" weight="bold" aria-hidden="true" />
                Keep
              </button>
            </>
          ) : (
            <>
              {/* Status quick-select */}
              <label className="sr-only" htmlFor={`status-${script.id}`}>
                Status of {script.title}
              </label>
              <select
                id={`status-${script.id}`}
                value={script.status}
                disabled={busy || locked > 0}
                onChange={(e) => {
                  const next = e.target.value as ScriptStatus;
                  patch.mutate(
                    { status: next },
                    {
                      onSuccess: () =>
                        toast.success("Status updated", {
                          description: `${script.title} is now ${STATUS_META[next].label.toLowerCase()}.`,
                        }),
                    }
                  );
                }}
                className="h-10 cursor-pointer rounded-xl border border-[#2b2b3a] bg-black/70 px-3 font-mono text-[11px] font-bold tracking-wide text-neutral-200 uppercase transition-colors duration-200 hover:border-ledz/50 focus:border-ledz/70 focus:ring-ledz/40 focus:ring-2 focus:outline-none disabled:cursor-not-allowed disabled:opacity-50"
              >
                {SCRIPT_STATUSES.map((s) => (
                  <option key={s} value={s} className="bg-neutral-950">
                    {STATUS_META[s].label}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => setEditing(true)}
                className="border-ledz-border text-neutral-300 hover:border-ledz/60 hover:text-white flex h-10 w-10 cursor-pointer items-center justify-center rounded-xl border transition-colors duration-200"
                aria-label={`Edit ${script.title}`}
              >
                <PencilSimple className="h-4 w-4" weight="bold" aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={() => setConfirmingDelete(true)}
                className="border-red-500/25 text-red-400 hover:border-red-500/60 hover:bg-red-500/10 flex h-10 w-10 cursor-pointer items-center justify-center rounded-xl border transition-colors duration-200"
                aria-label={`Delete ${script.title}`}
              >
                <TrashSimple className="h-4 w-4" weight="bold" aria-hidden="true" />
              </button>
            </>
          )}
        </div>
      </div>
    </li>
  );
}

/* ────────────────────────── Dashboard ────────────────────────── */

function Dashboard({ onLogout }: { onLogout: () => void }) {
  const qc = useQueryClient();
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: adminScriptsKey,
    queryFn: () => api<ScriptsResponse>("/api/admin/scripts"),
    retry: false,
  });

  const logout = useMutation({
    mutationFn: () => api("/api/admin/logout", { method: "POST" }),
    onSuccess: () => {
      qc.clear();
      onLogout();
    },
  });

  const scripts = data?.scripts ?? [];
  const counts = SCRIPT_STATUSES.map((s) => ({
    status: s,
    n: scripts.filter((x) => x.status === s).length,
  }));

  return (
    <div className="min-h-screen">
      {/* Admin bar */}
      <header className="hairline-red sticky top-0 z-40 border-b border-ledz-border/60 bg-black/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="border-ledz/40 from-neutral-900 to-black flex h-10 w-10 items-center justify-center rounded-2xl border bg-gradient-to-b shadow-[0_0_20px_-6px_rgba(255,0,60,0.55)]">
              <ZMark size={24} />
            </span>
            <div>
              <p className="text-sm leading-none font-bold tracking-tight text-white">
                LedZ Hub <span className="text-ledz">Admin</span>
              </p>
              <p className="mt-1 font-mono text-[10px] tracking-[0.2em] text-neutral-500 uppercase">
                Script hub control
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <a
              href="/"
              className="border-ledz-border text-neutral-300 hover:border-ledz/60 hover:bg-ledz/10 hover:text-white flex h-10 items-center gap-2 rounded-xl border px-4 font-mono text-[11px] font-bold tracking-[0.15em] uppercase transition-colors duration-200"
            >
              <ArrowLeft className="h-3.5 w-3.5" weight="bold" aria-hidden="true" />
              <span className="hidden sm:inline">View site</span>
            </a>
            <button
              type="button"
              onClick={() => logout.mutate()}
              disabled={logout.isPending}
              className="border-red-500/25 text-red-400 hover:border-red-500/60 hover:bg-red-500/10 flex h-10 cursor-pointer items-center gap-2 rounded-xl border px-4 font-mono text-[11px] font-bold tracking-[0.15em] uppercase transition-colors duration-200 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <SignOut className="h-3.5 w-3.5" weight="bold" aria-hidden="true" />
              {logout.isPending ? "..." : "Log out"}
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl space-y-6 px-4 py-8 sm:px-6">
        {/* Live status line: real counts from the same list below */}
        <div className="flex flex-wrap items-center gap-2.5">
          <span className="border-ledz-border bg-neutral-950 rounded-full border px-4 py-2 font-mono text-[11px] font-bold tracking-[0.15em] text-white uppercase">
            {isLoading ? "Loading..." : `${scripts.length} scripts total`}
          </span>
          {counts.map(({ status, n }) => (
            <span
              key={status}
              className={`rounded-full border px-3.5 py-2 font-mono text-[11px] font-bold tracking-[0.12em] uppercase ${STATUS_META[status].text} ${STATUS_META[status].border} ${STATUS_META[status].bg}`}
            >
              {n} {STATUS_META[status].label.toLowerCase()}
            </span>
          ))}
        </div>

        <AddScriptForm />

        {/* List */}
        {isLoading ? (
          <div
            className="border-ledz-border bg-void-raised/70 space-y-3 rounded-[22px] border p-5"
            aria-busy="true"
            aria-label="Loading scripts"
          >
            {Array.from({ length: 4 }, (_, i) => (
              <div key={i} className="skeleton-shimmer h-14 rounded-xl" />
            ))}
          </div>
        ) : isError ? (
          <div className="border-red-500/30 bg-red-500/5 flex flex-col items-center gap-4 rounded-[22px] border px-6 py-12 text-center">
            <WarningCircle className="h-9 w-9 text-red-400" weight="bold" aria-hidden="true" />
            <div className="space-y-1">
              <p className="font-bold text-white">Could not load the hub</p>
              <p className="font-mono text-xs text-neutral-400">
                {(error as Error)?.message ?? "The request failed."}
              </p>
            </div>
            <button
              type="button"
              onClick={() => refetch()}
              className="border-ledz-border text-neutral-200 hover:border-ledz/60 hover:text-white cursor-pointer rounded-xl border px-5 py-2.5 font-mono text-[11px] font-bold tracking-[0.15em] uppercase transition-colors duration-200"
            >
              Try again
            </button>
          </div>
        ) : scripts.length === 0 ? (
          <div className="border-ledz-border bg-void-raised/70 flex flex-col items-center gap-3 rounded-[22px] border px-6 py-14 text-center">
            <p className="font-bold text-white">The hub is empty</p>
            <p className="max-w-sm text-sm leading-relaxed text-neutral-400">
              Add the first script with the form above and it goes live on the
              hub instantly.
            </p>
          </div>
        ) : (
          <ul className="border-ledz-border bg-void-raised/70 overflow-hidden rounded-[22px] border">
            {scripts.map((s) => (
              <ScriptRow key={s.id} script={s} />
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}

/* ────────────────────────── Root ────────────────────────── */

function AdminPanelInner() {
  const session = useQuery({
    queryKey: ["admin-session"],
    queryFn: () =>
      api<{
        authed: boolean;
        loginRetryAfter: number;
        writeRetryAfter?: number;
        readRetryAfter?: number;
      }>("/api/admin/session"),
  });

  /* Login/logout override so the UI reacts instantly; the session
     query remains the source of truth. */
  const [override, setOverride] = useState<null | boolean>(null);
  const authed: boolean | null = session.data
    ? (override ?? session.data.authed)
    : null;

  useEffect(() => {
    const data = session.data;
    if (!data) return;
    /* Refreshed while rate limited? The server tells us every open
       window, so the buttons come back already counting down instead
       of granting one wasted click before the 429 lands. */
    if (!data.authed && data.loginRetryAfter > 0) {
      reportLockSeconds(data.loginRetryAfter);
    }
    if (data.authed) {
      const writeLock = data.writeRetryAfter ?? 0;
      const readLock = data.readRetryAfter ?? 0;
      const worst = Math.max(writeLock, readLock);
      if (worst > 0) reportLockSeconds(worst);
    }
  }, [session.data]);

  const handleLogin = useCallback(() => setOverride(true), []);
  const handleLogout = useCallback(() => setOverride(null), []);

  if (authed === null) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="border-ledz-border border-t-ledz h-9 w-9 animate-spin rounded-full border-2" aria-label="Loading" />
      </div>
    );
  }

  return authed ? (
    <Dashboard onLogout={handleLogout} />
  ) : (
    <LoginGate onAuthed={handleLogin} />
  );
}

export default function AdminPanel() {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { staleTime: 10_000, refetchOnWindowFocus: false, retry: 1 },
        },
      })
  );

  return (
    <QueryClientProvider client={queryClient}>
      <div className="relative min-h-screen bg-void">
        <div className="noise-overlay" aria-hidden="true" />
        <AdminPanelInner />
      </div>
    </QueryClientProvider>
  );
}
