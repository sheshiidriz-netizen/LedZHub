"use client";

import { ZMark, ZWordmark } from "./ZLogo";

export function HubFooter() {
  return (
    <footer className="hairline-red relative mt-auto border-t border-ledz-border/60 bg-black/80 py-8 backdrop-blur-md">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center gap-4 px-4 sm:px-6">
        <div className="flex items-center gap-3">
          <span className="border-ledz/30 from-neutral-900 to-black shadow-ledz/20 flex h-9 w-9 items-center justify-center rounded-2xl border bg-gradient-to-b shadow-[0_0_18px_-6px_rgba(255,0,60,0.5)]">
            <ZMark size={20} />
          </span>
          <ZWordmark compact />
        </div>
        <p className="font-mono text-[11px] text-neutral-500">
          © 2026 <span className="font-bold text-neutral-300">LedZ Hub</span>
        </p>
      </div>
    </footer>
  );
}
