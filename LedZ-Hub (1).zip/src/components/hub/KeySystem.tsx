"use client";

import { useCallback, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  Key,
  Check,
  Copy,
  ShieldCheck,
  LinkBreak,
  LockKey,
} from "@phosphor-icons/react";
import { KEY_INFO } from "@/lib/hub-data";
import { copyText } from "@/lib/clipboard";
import { toast } from "sonner";
import { EASE_ENTER } from "@/lib/motion";
import { fetchKeyResilient, keyQueryKey } from "./hub-queries";
import { Reveal } from "./Reveal";

const STEPS = [
  {
    title: "Copy the key",
    body: (k: string) => (
      <>
        Grab <code className="text-ledz font-mono font-bold">{k}</code> with the
        copy button. It is the same for every script in the hub.
      </>
    ),
  },
  {
    title: "Run any script",
    body: () => (
      <>
        Pick a loadstring from the{" "}
        <span className="font-bold text-white">Scripts</span> tab and execute it
        in your executor.
      </>
    ),
  },
  {
    title: "Activate once",
    body: (k: string) => (
      <>
        Paste <code className="text-ledz font-mono font-bold">{k}</code> into the
        in-game prompt. Every feature unlocks instantly, for good.
      </>
    ),
  },
] as const;

const TRUST = [
  { icon: ShieldCheck, label: "No ads" },
  { icon: LinkBreak, label: "No link shorteners" },
  { icon: LockKey, label: "No per-game keys" },
] as const;

export function KeySystem({ entered }: { entered: boolean }) {
  const { data } = useQuery({
    queryKey: keyQueryKey,
    queryFn: fetchKeyResilient,
  });

  const keyValue = data?.key ?? KEY_INFO.key;
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleCopy = useCallback(async () => {
    const ok = await copyText(keyValue);
    if (ok) {
      toast.success("Universal key copied", {
        description: "Activate it in-game to unlock every script.",
        icon: <Key className="h-4 w-4 text-ledz" weight="bold" aria-hidden="true" />,
      });
      if (timer.current) clearTimeout(timer.current);
      setCopied(true);
      timer.current = setTimeout(() => setCopied(false), 1600);
    } else {
      toast.error("Copy failed", {
        description: "Your browser blocked the clipboard. Copy the code manually.",
      });
    }
  }, [keyValue]);

  return (
    <div className="mx-auto max-w-2xl space-y-6 py-2">
      {/* Header */}
      <div className="space-y-3 text-center">
        <h2 className="text-3xl font-extrabold tracking-tight text-white uppercase sm:text-4xl">
          <span className={`mask-line ${entered ? "mask-in" : ""}`}>
            <span className="mask-word">The universal</span>
          </span>{" "}
          <span className={`mask-line ${entered ? "mask-in" : ""}`}>
            <span
              className="text-ledz text-glow-red mask-word"
              style={{ transitionDelay: "90ms" }}
            >
              LedZ key
            </span>
          </span>
        </h2>
        <Reveal active={entered} delay={0.3}>
          <p className="mx-auto max-w-md text-sm leading-relaxed text-neutral-400">
            One key unlocks the entire hub. Copy it once, activate it in-game,
            and every script is yours.
          </p>
        </Reveal>
      </div>

      {/* Key card */}
      <Reveal active={entered} delay={0.2}>
        <div className="panel-frame box-glow-red group relative space-y-7 overflow-hidden rounded-[28px] p-6 sm:p-8">
          <div
            className="from-ledz/0 via-ledz/50 to-ledz/0 pointer-events-none absolute inset-x-8 top-0 h-px bg-gradient-to-r"
            aria-hidden="true"
          />

          <div className="border-neutral-800 flex flex-wrap items-center justify-between gap-3 border-b pb-5">
            <div className="flex items-center gap-3">
              <div className="border-ledz-border bg-neutral-900/90 text-ledz flex h-11 w-11 items-center justify-center rounded-2xl border shadow-inner">
                <Key className="h-[18px] w-[18px]" weight="bold" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white sm:text-lg">
                  {data?.label ?? KEY_INFO.label}
                </h3>
                <p className="font-mono text-[11px] tracking-wider text-neutral-400">
                  {data?.status ?? KEY_INFO.status}
                </p>
              </div>
            </div>
          </div>

          {/* Key display with rotating conic frame + scanline */}
          <div className="space-y-3">
            <span className="font-mono text-[10px] tracking-[0.25em] text-neutral-400 uppercase">
              Universal Key Code
            </span>
            <div className="flex flex-col items-stretch gap-3 sm:flex-row">
              <div className="conic-frame w-full">
                <div
                  role="button"
                  tabIndex={0}
                  aria-label="Copy the universal key code"
                  onClick={handleCopy}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      handleCopy();
                    }
                  }}
                  className="relative flex min-h-[60px] items-center justify-center overflow-hidden rounded-[16px] bg-black/90 px-4 py-4 text-center"
                >
                  <span
                    className={`text-ledz text-glow-red tabular relative z-10 font-mono text-2xl font-extrabold tracking-[0.2em] select-all sm:text-3xl ${
                      copied ? "opacity-70" : ""
                    }`}
                  >
                    {keyValue}
                  </span>
                  <span className="scanline" aria-hidden="true" />
                </div>
              </div>
              <button
                type="button"
                onClick={handleCopy}
                className={`btn-primary btn-sheen h-auto min-h-[56px] w-full shrink-0 rounded-2xl px-7 py-4 text-[13px] font-extrabold tracking-[0.15em] uppercase sm:w-auto ${
                  copied ? "is-copied" : ""
                }`}
              >
                <span className="btn-glyph" aria-hidden="true">
                  <Copy className="glyph-idle h-4 w-4" weight="bold" />
                  <Check className="glyph-done h-4 w-4 text-emerald-300" weight="bold" />
                </span>
                <span className="relative">
                  <span
                    className={
                      copied ? "opacity-0" : "opacity-100 transition-opacity duration-150"
                    }
                  >
                    Copy Key
                  </span>
                  <span
                    className={`pointer-events-none absolute inset-0 flex items-center justify-center transition-opacity duration-150 ${
                      copied ? "opacity-100" : "opacity-0"
                    }`}
                  >
                    Copied
                  </span>
                </span>
              </button>
            </div>
          </div>

          {/* Steps */}
          <div className="border-neutral-800 space-y-4 border-t pt-6">
            <h4 className="font-mono text-xs font-bold tracking-[0.2em] text-neutral-300 uppercase">
              How to activate
            </h4>
            <ol className="space-y-4">
              {STEPS.map((step, i) => (
                <motion.li
                  key={step.title}
                  initial={{ opacity: 0, x: -12 }}
                  animate={
                    entered ? { opacity: 1, x: 0 } : { opacity: 0, x: -12 }
                  }
                  transition={{
                    duration: 0.45,
                    delay: 0.4 + i * 0.12,
                    ease: EASE_ENTER,
                  }}
                  className="relative flex items-start gap-3.5"
                >
                  <span className="border-ledz/30 bg-neutral-900 text-ledz z-10 mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border font-mono text-[11px] font-bold shadow-[0_0_12px_-2px_rgba(255,0,60,0.4)]">
                    {i + 1}
                  </span>
                  {i < STEPS.length - 1 && (
                    <span
                      className="from-ledz/40 absolute top-9 left-[13.5px] h-[calc(100%-14px)] w-px rounded-full bg-gradient-to-b to-transparent"
                      aria-hidden="true"
                    />
                  )}
                  <span className="space-y-0.5 text-sm leading-relaxed text-neutral-400">
                    <span className="block text-[13px] font-bold tracking-wide text-white uppercase">
                      {step.title}
                    </span>
                    <span className="block">{step.body(keyValue)}</span>
                  </span>
                </motion.li>
              ))}
            </ol>
          </div>

          {/* Trust row */}
          <div className="border-neutral-800/70 flex flex-wrap items-center justify-center gap-x-6 gap-y-2.5 border-t pt-5">
            {TRUST.map(({ icon: Icon, label }) => (
              <span
                key={label}
                className="flex items-center gap-1.5 font-mono text-[10px] font-bold tracking-[0.15em] text-neutral-500 uppercase"
              >
                <Icon className="text-ledz/70 h-3.5 w-3.5" weight="bold" aria-hidden="true" />
                {label}
              </span>
            ))}
          </div>
        </div>
      </Reveal>
    </div>
  );
}
