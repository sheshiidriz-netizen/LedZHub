"use client";

import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { GameController } from "@phosphor-icons/react";
import { rankScripts, type HubScript } from "@/lib/hub-data";
import { useDebouncedValue } from "@/lib/use-debounced-value";
import { fetchSuggest, scriptsQueryKey, fetchScriptsResilient } from "./hub-queries";

/**
 * Everything the search dropdowns need, shared by the header search
 * and the hero search: instant local ranking for zero-latency first
 * paint, refined by the server (DB with the Rust core as fallback)
 * once the debounced query settles.
 */
export function useScriptSuggestions(query: string, scripts: HubScript[]) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);

  const trimmed = query.trim();
  const debounced = useDebouncedValue(trimmed, 120);

  const server = useQuery({
    queryKey: ["script-suggest", debounced],
    queryFn: () => fetchSuggest(debounced),
    enabled: debounced.length > 0,
    staleTime: 60_000,
    retry: 0,
  });

  const items = useMemo(() => {
    const data = server.data;
    if (data && data.query === debounced) return data.scripts;
    return rankScripts(scripts, trimmed);
  }, [server.data, debounced, scripts, trimmed]);

  return { items, open, setOpen, active, setActive, trimmed };
}

/**
 * The dropdown itself: rounded hairline panel under the input, rows
 * with a game chip, a truncated title (long names end in "…") and the
 * category. Hover and keyboard highlight share one active index.
 */
export function SuggestPanel({
  items,
  query,
  activeIndex,
  listboxId,
  onPick,
  onHover,
}: {
  items: HubScript[];
  query: string;
  activeIndex: number;
  listboxId: string;
  onPick: (script: HubScript) => void;
  onHover: (index: number) => void;
}) {
  return (
    <div
      onMouseDown={(e) => e.preventDefault()}
      className="border-ledz-border/90 absolute top-full right-0 left-0 z-50 mt-2 overflow-hidden rounded-2xl border bg-black/95 shadow-[0_24px_60px_-18px_rgba(0,0,0,0.9)] backdrop-blur-xl"
    >
      <ul
        id={listboxId}
        role="listbox"
        aria-label="Script suggestions"
        className="max-h-[320px] overflow-y-auto p-1.5"
      >
        {items.length === 0 ? (
          <li
            role="option"
            aria-selected="false"
            aria-disabled="true"
            className="px-3.5 py-3.5 font-mono text-xs text-neutral-500"
          >
            No scripts match{" "}
            <span className="text-ledz">{query}</span>. Try another game
            name.
          </li>
        ) : (
          items.map((script, i) => {
            const isActive = i === activeIndex;
            return (
              <li key={script.id} role="option" aria-selected={isActive}>
                <button
                  type="button"
                  id={`${listboxId}-opt-${i}`}
                  onClick={() => onPick(script)}
                  onMouseEnter={() => onHover(i)}
                  className={`group flex w-full cursor-pointer items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors duration-150 ${
                    isActive ? "bg-ledz/15" : "hover:bg-ledz/10"
                  }`}
                >
                  <span
                    className={`border-ledz-border bg-neutral-950 text-ledz flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border shadow-inner transition-colors duration-150 ${
                      isActive ? "border-ledz/60" : ""
                    }`}
                  >
                    <GameController
                      className="h-4 w-4"
                      weight="bold"
                      aria-hidden="true"
                    />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold text-white">
                      {script.title}
                    </span>
                  </span>
                  <span className="shrink-0 font-mono text-[10px] tracking-[0.12em] text-neutral-500 uppercase">
                    {script.category}
                  </span>
                </button>
              </li>
            );
          })
        )}
      </ul>
    </div>
  );
}

/** Same scripts cache the hub grid uses: no extra request. */
export function useHubScripts(): HubScript[] {
  const { data } = useQuery({
    queryKey: scriptsQueryKey,
    queryFn: fetchScriptsResilient,
  });
  return useMemo(() => data?.scripts ?? [], [data]);
}
