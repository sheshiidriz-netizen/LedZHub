"use client";

import { Component, useEffect, useMemo, useRef, type ReactNode } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

/* ── Safety net: if WebGL is unavailable, the site simply runs flat ── */
class GLBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? null : this.props.children;
  }
}

/* ── Additive nebula of neon-red particles, nothing off-scheme ── */

/** Soft round sprite so particles glow as orbs, never squares. */
function makeGlowTexture(): THREE.Texture {
  const size = 64;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.35, "rgba(255,255,255,0.55)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

function NebulaParticles({ count = 640 }: { count?: number }) {
  const ref = useRef<THREE.Points>(null);
  const texture = useMemo(() => makeGlowTexture(), []);

  const geometry = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 1800;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 1000;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 1400;
      const r = Math.random();
      let cr: number, cg: number, cb: number;
      if (r > 0.92) {
        cr = 1; cg = 0.55; cb = 0.66; // hot pink-red sparks, never white
      } else if (r > 0.86) {
        cr = 0.45; cg = 0; cb = 0.1; // deep ember
      } else {
        cr = 1; cg = 0; cb = 0.235; // neon red #ff003c
      }
      colors[i * 3] = cr;
      colors[i * 3 + 1] = cg;
      colors[i * 3 + 2] = cb;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    g.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    return g;
  }, [count]);

  useEffect(() => {
    geometry.dispose();
    texture.dispose();
  }, [geometry, texture]);

  useFrame((_, dt) => {
    if (ref.current) {
      ref.current.rotation.y += dt * 0.012;
      ref.current.rotation.z += dt * 0.004;
    }
  });

  return (
    <points ref={ref} geometry={geometry}>
      <pointsMaterial
        size={3.8}
        map={texture}
        vertexColors
        transparent
        opacity={0.85}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

/* ── Slow-drifting wireframe geometry ───────────────────────────── */
interface WireShapeProps {
  geometry: THREE.BufferGeometry;
  position: [number, number, number];
  scale?: number;
  speed?: [number, number];
  float?: number;
  opacity?: number;
}

function WireShape({
  geometry,
  position,
  scale = 1,
  speed = [0.05, 0.08],
  float = 1.2,
  opacity = 0.08,
}: WireShapeProps) {
  const ref = useRef<THREE.Mesh>(null);
  const phase = useMemo(() => Math.random() * Math.PI * 2, []);

  useFrame((state, dt) => {
    const m = ref.current;
    if (!m) return;
    m.rotation.x += dt * speed[0];
    m.rotation.y += dt * speed[1];
    m.position.y =
      position[1] + Math.sin(state.clock.elapsedTime * 0.5 + phase) * float * 10;
  });

  return (
    <mesh ref={ref} geometry={geometry} position={position} scale={scale}>
      <meshBasicMaterial color="#ff003c" wireframe transparent opacity={opacity} />
    </mesh>
  );
}

function WireShapes() {
  const geometries = useMemo(
    () => ({
      icosahedron: new THREE.IcosahedronGeometry(70, 1),
      torusKnot: new THREE.TorusKnotGeometry(34, 10, 64, 8),
      octahedron: new THREE.OctahedronGeometry(48, 0),
    }),
    []
  );

  useEffect(() => {
    return () => Object.values(geometries).forEach((g) => g.dispose());
  }, [geometries]);

  return (
    <group>
      <WireShape
        geometry={geometries.icosahedron}
        position={[-420, 160, -160]}
        speed={[0.04, 0.06]}
        float={1.4}
        opacity={0.07}
      />
      <WireShape
        geometry={geometries.torusKnot}
        position={[430, -110, -220]}
        scale={1.15}
        speed={[0.05, 0.09]}
        float={1}
        opacity={0.06}
      />
      <WireShape
        geometry={geometries.octahedron}
        position={[-340, -190, -60]}
        speed={[0.07, 0.05]}
        float={1.6}
        opacity={0.08}
      />
    </group>
  );
}

/* ── Pointer parallax + gentle scroll drift ─────────────────────── */
function ParallaxRig() {
  const target = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      target.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      target.current.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, []);

  // Reads camera from the frame state (not from a hook value in render),
  // so the r3f camera can be nudged safely each frame. Smoothing is
  // frame-rate independent, so the scene tracks the pointer the same
  // way at 60 and 144 Hz.
  useFrame((state, delta) => {
    const cam = state.camera;
    const dt = Math.min(delta, 0.05);
    const k = 1 - Math.pow(1 - 0.08, dt * 60);
    const drift = window.scrollY * 0.02;
    cam.position.x += (target.current.x * 48 - cam.position.x) * k;
    cam.position.y += (-target.current.y * 28 - cam.position.y) * k;
    cam.position.z += (420 + drift - cam.position.z) * k;
    cam.lookAt(0, 0, 0);
  });

  return null;
}

/* ── Half-rate heartbeat ───────────────────────────────────── */

/**
 * The nebula drifts so slowly that 30fps reads exactly like 60fps,
 * but the saving is real: every backdrop-blur layer above this
 * canvas only recomposites when the canvas actually changes, so
 * halving the render rate halves the cost of the whole stack.
 */
function HalfRateClock({ active }: { active: boolean }) {
  const invalidate = useThree((s) => s.invalidate);

  useEffect(() => {
    if (!active) return;
    const FRAME_MS = 1000 / 30;
    let last = 0;
    let raf = 0;
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      if (now - last >= FRAME_MS) {
        last = now;
        invalidate();
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, invalidate]);

  return null;
}

/* ── Scene ──────────────────────────────────────────────────────── */
export default function BackgroundScene({ entered }: { entered: boolean }) {
  const reduced =
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* The scene is invisible until the splash hands over: rendering it
     behind an opacity-0 layer burned GPU time for nothing. */
  const running = entered && !reduced;

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-0 transition-opacity ease-out ${
        entered ? "opacity-100 duration-[1200ms]" : "opacity-0 duration-700"
      }`}
    >
      <GLBoundary>
        <Canvas
          camera={{ position: [0, 0, 420], fov: 60 }}
          dpr={[1, 1.35]}
          gl={{
            antialias: false,
            alpha: true,
            powerPreference: "high-performance",
          }}
          frameloop={running ? "demand" : "never"}
        >
          <fog attach="fog" args={["#070103", 700, 1600]} />
          <NebulaParticles />
          <WireShapes />
          <ParallaxRig />
          <HalfRateClock active={running} />
        </Canvas>
      </GLBoundary>
    </div>
  );
}
