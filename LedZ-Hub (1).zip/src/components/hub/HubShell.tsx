"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import { AnimatePresence } from "framer-motion";
import { QueryClient, QueryClientProvider, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { GameController } from "@phosphor-icons/react";
import {
  SCRIPTS,
  filterScripts,
  type HubScript,
} from "@/lib/hub-data";
import { copyText } from "@/lib/clipboard";
import { Header, type HubTab } from "./Header";
import { HeroBanner } from "./HeroBanner";
import { ScriptsGrid } from "./ScriptsGrid";
import { KeySystem } from "./KeySystem";
import { PageSlider } from "./PageSlider";
import { HubFooter } from "./HubFooter";
import { fetchScriptsResilient, scriptsQueryKey } from "./hub-queries";

/* Client-only islands (WebGL / WebGPU / DOM APIs) */
const BackgroundScene = dynamic(() => import("./BackgroundScene"), { ssr: false });
const VoidSplash = dynamic(() => import("./VoidSplash"), { ssr: false });
const CursorGlow = dynamic(() => import("./CursorGlow"), { ssr: false });

function ScriptsPage({
  entered,
  query,
  onQueryChange,
  onPickScript,
  onCopy,
}: {
  entered: boolean;
  query: string;
  onQueryChange: (q: string) => void;
  onPickScript: (s: HubScript) => void;
  onCopy: (s: HubScript) => void;
}) {
  const { data } = useQuery({
    queryKey: scriptsQueryKey,
    queryFn: fetchScriptsResilient,
  });

  const scripts = data?.scripts ?? SCRIPTS;
  const total = data?.total ?? SCRIPTS.length;
  const showing = useMemo(
    () => filterScripts(scripts, query).length,
    [scripts, query]
  );

  return (
    <>
      <section className="space-y-6" aria-label="Script database">
        <HeroBanner
          entered={entered}
          query={query}
          onQueryChange={onQueryChange}
          onPickScript={onPickScript}
          scripts={scripts}
          total={total}
          showing={showing}
        />
        <ScriptsGrid query={query} onCopy={onCopy} onClear={() => onQueryChange("")} />
      </section>
    </>
  );
}

function Hub() {
  const [entered, setEntered] = useState(false);
  const [tab, setTab] = useState<HubTab>("scripts");
  const [query, setQuery] = useState("");
  const qc = useQueryClient();

  /* Live counter: when a script is added, edited or removed in the
     admin panel (same tab or another one), a localStorage broadcast
     wakes this query and the "N scripts in the hub" line updates
     within a heartbeat. */
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === "ledz-scripts-rev") {
        qc.invalidateQueries({ queryKey: scriptsQueryKey });
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [qc]);

  const handleCopy = useCallback(async (script: HubScript) => {
    const ok = await copyText(script.code);
    if (ok) {
      toast.success("Loadstring copied", {
        description: "Paste it into your executor and run.",
        icon: <GameController className="h-4 w-4 text-ledz" weight="bold" aria-hidden="true" />,
      });
    } else {
      toast.error("Copy failed", {
        description: "Your browser blocked the clipboard. Copy the code manually.",
      });
    }
  }, []);

  const handleTabChange = useCallback((t: HubTab) => {
    setTab(t);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  /* Search dropdown pick: clear the filter (so the full grid shows),
     land on the scripts tab, then glide to the card and pulse it. The
     suggestion list is always fresher than the grid cache, so the
     scripts query is refreshed and the glide retries briefly until
     the card from the fresh list is in the DOM. */
  const handlePickScript = useCallback(
    (script: HubScript) => {
      setQuery("");
      setTab("scripts");
      void qc.invalidateQueries({ queryKey: scriptsQueryKey });

      const tryScroll = (attempt: number) => {
        const el = document.getElementById(`script-card-${script.id}`);
        if (el) {
          el.scrollIntoView({ behavior: "smooth", block: "center" });
          el.classList.add("script-highlight");
          window.setTimeout(
            () => el.classList.remove("script-highlight"),
            2600
          );
          return;
        }
        if (attempt < 5) {
          window.setTimeout(() => tryScroll(attempt + 1), 220);
        }
      };
      window.setTimeout(() => tryScroll(0), 620);
    },
    [qc]
  );

  /* Same cache key: no duplicate request */
  const { data } = useQuery({
    queryKey: scriptsQueryKey,
    queryFn: fetchScriptsResilient,
  });

  return (
    <div className="relative flex min-h-screen flex-col bg-void">
      <BackgroundScene entered={entered} />
      <div className="noise-overlay" aria-hidden="true" />
      <div className="vignette-overlay" aria-hidden="true" />
      <CursorGlow />

      {/* Splash: a static placeholder avoids any content flash before
          mount; the real splash unmounts with its own exit. */}
      {!entered && (
        <div className="fixed inset-0 z-[100] bg-void-deep" aria-hidden="true" />
      )}
      <AnimatePresence>
        {!entered && <VoidSplash onComplete={() => setEntered(true)} />}
      </AnimatePresence>

      <div className="relative z-10 flex min-h-screen flex-col">
        <Header
          tab={tab}
          onTabChange={handleTabChange}
          entered={entered}
          query={query}
          onQueryChange={setQuery}
          onPickScript={handlePickScript}
        />

        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6 sm:py-8">
          <PageSlider
            tab={tab}
            scriptsPage={
              <ScriptsPage
                entered={entered}
                query={query}
                onQueryChange={setQuery}
                onPickScript={handlePickScript}
                onCopy={handleCopy}
              />
            }
            keyPage={<KeySystem entered={entered && tab === "key"} />}
          />
        </main>

        <HubFooter />
      </div>
    </div>
  );
}

export default function HubShell() {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            /* Short staleness + focus refetch: the hub counter and grid
               follow the admin panel without a manual reload. */
            staleTime: 15_000,
            refetchOnWindowFocus: true,
            retry: 1,
          },
        },
      })
  );

  return (
    <QueryClientProvider client={queryClient}>
      <Hub />
    </QueryClientProvider>
  );
}
