"use client";

import { useCallback, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  GameController,
  Check,
  Copy,
  SealCheck,
  Wrench,
  Bandaids,
  Prohibit,
  CurrencyCircleDollar,
  LockOpen,
  Key,
} from "@phosphor-icons/react";
import type {
  HubScript,
  ScriptBadge,
  ScriptStatus,
} from "@/lib/hub-data";
import { BADGE_META, STATUS_META } from "@/lib/script-status";
import { EASE_ENTER } from "@/lib/motion";

const STATUS_ICONS = {
  working: SealCheck,
  in_progress: Wrench,
  patched: Bandaids,
  not_working: Prohibit,
} as const satisfies Record<ScriptStatus, typeof SealCheck>;

export const BADGE_ICONS = {
  paid: CurrencyCircleDollar,
  keyless: LockOpen,
  key_system: Key,
} as const satisfies Record<ScriptBadge, typeof Key>;

/** Live status badge: the color, icon, and label all come from the
 *  database, so a card can never claim a status it does not have. */
export function StatusBadge({
  status,
  size = "md",
}: {
  status: ScriptStatus;
  size?: "sm" | "md";
}) {
  const meta = STATUS_META[status];
  const Icon = STATUS_ICONS[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-3 font-mono font-semibold tracking-[0.14em] uppercase ${meta.text} ${meta.border} ${meta.bg} ${
        size === "sm" ? "py-0.5 text-[10px]" : "py-1 text-[11px]"
      }`}
    >
      <Icon className="h-3.5 w-3.5" weight="bold" aria-hidden="true" />
      {meta.label}
    </span>
  );
}

/** Attribute badge (Paid, Keyless, Key System): rendered only when the
 *  admin assigned it, styled from the same catalog the API validates. */
export function BadgePill({
  badge,
  size = "md",
}: {
  badge: ScriptBadge;
  size?: "sm" | "md";
}) {
  const meta = BADGE_META[badge];
  const Icon = BADGE_ICONS[badge];
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2.5 font-mono font-semibold tracking-[0.14em] uppercase ${meta.text} ${meta.border} ${meta.bg} ${
        size === "sm" ? "py-0.5 text-[9px]" : "py-1 text-[10px]"
      }`}
    >
      <Icon className="h-3 w-3" weight="bold" aria-hidden="true" />
      {meta.label}
    </span>
  );
}

export function ScriptCard({
  script,
  index,
  onCopy,
}: {
  script: HubScript;
  index: number;
  onCopy: (script: HubScript) => void;
}) {
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleCopy = useCallback(() => {
    onCopy(script);
    if (timer.current) clearTimeout(timer.current);
    setCopied(true);
    timer.current = setTimeout(() => setCopied(false), 1600);
  }, [onCopy, script]);

  return (
    <motion.article
      layout
      id={`script-card-${script.id}`}
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.45, ease: EASE_ENTER }}
      className="h-full"
    >
      <div className="card-wash group border-ledz-border bg-void-raised/70 relative flex h-full flex-col gap-5 rounded-[24px] border p-6 backdrop-blur-[6px] transition-[transform,border-color,box-shadow] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-1.5 hover:border-ledz/50 hover:shadow-[0_24px_60px_-22px_rgba(255,0,60,0.45)]">
        <span className="ignite-top" aria-hidden="true" />

        {/* Header row: live status + assigned badges + index */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={script.status} />
            {script.badges.map((b) => (
              <BadgePill key={b} badge={b} />
            ))}
          </div>
          <span className="tabular font-mono text-xs font-bold text-neutral-600 transition-colors duration-200 group-hover:text-ledz/80">
            {String(index + 1).padStart(2, "0")}
          </span>
        </div>

        {/* Title: fixed two-line space keeps code blocks aligned */}
        <h3 className="flex min-h-[50px] items-center gap-2.5 text-lg font-bold tracking-wide text-white">
          <span className="border-ledz-border bg-neutral-950 text-ledz flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border shadow-inner">
            <GameController className="h-[18px] w-[18px]" weight="bold" aria-hidden="true" />
          </span>
          <span className="leading-snug">{script.title}</span>
        </h3>

        {/* Loadstring box: click to copy */}
        <div
          role="button"
          tabIndex={0}
          aria-label={`Copy ${script.title} loadstring`}
          onClick={handleCopy}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              handleCopy();
            }
          }}
          className="relative min-h-[92px] cursor-pointer overflow-hidden rounded-2xl border border-neutral-800 bg-black/90 p-3.5 font-mono text-[13px] leading-relaxed break-all text-ledz transition-colors duration-200 select-all hover:border-ledz/50"
        >
          <span className="code-shine" aria-hidden="true" />
          <code className="relative z-10">{script.code}</code>
        </div>

        {/* Copy button */}
        <button
          type="button"
          onClick={handleCopy}
          className={`btn-primary btn-sheen mt-auto flex h-12 w-full cursor-pointer items-center justify-center gap-2.5 rounded-2xl px-4 text-[13px] font-bold tracking-[0.12em] text-white uppercase ${
            copied ? "is-copied" : ""
          }`}
        >
          <span className="btn-glyph" aria-hidden="true">
            <Copy className="glyph-idle h-4 w-4 text-white" weight="bold" />
            <Check className="glyph-done h-4 w-4 text-emerald-300" weight="bold" />
          </span>
          <span className="relative">
            <span
              className={
                copied ? "opacity-0" : "opacity-100 transition-opacity duration-150"
              }
            >
              Copy Loadstring
            </span>
            <span
              className={`pointer-events-none absolute inset-0 flex items-center justify-center transition-opacity duration-150 ${
                copied ? "opacity-100" : "opacity-0"
              }`}
            >
              Copied
            </span>
          </span>
        </button>
      </div>
    </motion.article>
  );
}
