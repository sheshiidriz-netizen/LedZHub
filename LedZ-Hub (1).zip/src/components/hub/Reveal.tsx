"use client";

import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { EASE_ENTER } from "@/lib/motion";

/**
 * Fade-up reveal used for hero / key-page children.
 * Fades in once `active` flips true; stays put afterwards.
 */
export function Reveal({
  active,
  delay = 0,
  y = 12,
  className,
  children,
}: {
  active: boolean;
  delay?: number;
  y?: number;
  className?: string;
  children: ReactNode;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y }}
      animate={active ? { opacity: 1, y: 0 } : { opacity: 0, y }}
      transition={{ duration: 0.52, delay, ease: EASE_ENTER }}
    >
      {children}
    </motion.div>
  );
}
