"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import { EASE_ENTER } from "@/lib/motion";
import type { HubTab } from "./Header";

/**
 * Two pages riding a 3D carousel track: the active page faces the
 * viewer while the departing page swings away with a gentle rotateY,
 * all inside a 1400px perspective.
 *
 * The track collapses to the ACTIVE page's height (measured with a
 * ResizeObserver and animated), so a short page never leaves you
 * scrolling through dead space below it.
 */
export function PageSlider({
  tab,
  scriptsPage,
  keyPage,
}: {
  tab: HubTab;
  scriptsPage: ReactNode;
  keyPage: ReactNode;
}) {
  const onScripts = tab === "scripts";
  const scriptsRef = useRef<HTMLDivElement>(null);
  const keyRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState<number | undefined>(undefined);

  useEffect(() => {
    const active = onScripts ? scriptsRef.current : keyRef.current;
    if (!active) return;
    const update = () => setHeight(active.offsetHeight);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(active);
    return () => ro.disconnect();
  }, [onScripts]);

  return (
    <div
      className="relative w-full overflow-hidden"
      style={{ perspective: "1400px" }}
    >
      <motion.div
        className="flex w-[200%] items-start will-change-transform"
        animate={{ x: onScripts ? "0%" : "-50%", height: height ?? "auto" }}
        transition={{ duration: 0.58, ease: EASE_ENTER }}
      >
        <div
          ref={scriptsRef}
          id="panel-scripts"
          role="tabpanel"
          aria-labelledby="tab-scripts"
          inert={!onScripts}
          className={`w-1/2 shrink-0 pr-1 transition-[transform,opacity] duration-[580ms] ease-[cubic-bezier(0.22,1,0.36,1)] sm:pr-3 ${
            onScripts
              ? "pointer-events-auto"
              : "pointer-events-none opacity-30 [transform:rotateY(5deg)_scale(0.95)]"
          }`}
        >
          {scriptsPage}
        </div>
        <div
          ref={keyRef}
          id="panel-key"
          role="tabpanel"
          aria-labelledby="tab-key"
          inert={onScripts}
          className={`w-1/2 shrink-0 pl-1 transition-[transform,opacity] duration-[580ms] ease-[cubic-bezier(0.22,1,0.36,1)] sm:pl-3 ${
            onScripts
              ? "pointer-events-none opacity-30 [transform:rotateY(-5deg)_scale(0.95)]"
              : "pointer-events-auto"
          }`}
        >
          {keyPage}
        </div>
      </motion.div>
    </div>
  );
}
