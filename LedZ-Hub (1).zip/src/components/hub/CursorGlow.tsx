"use client";

import { useEffect, useRef } from "react";

/**
 * Ambient red glow that trails the cursor (fine pointers only).
 * Lerped for a weightless, premium feel. Entirely imperative:
 * eligibility is handled by hiding the node, never via state.
 */
export default function CursorGlow() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const fine = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduced) {
      el.style.display = "none";
      return;
    }

    const target = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    const current = { ...target };
    let raf = 0;
    let visible = false;
    let last = performance.now();

    const tick = () => {
      const now = performance.now();
      /* Frame-rate independent smoothing: identical feel at 60 and 144 Hz. */
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      const dx = target.x - current.x;
      const dy = target.y - current.y;
      const k = 1 - Math.pow(1 - 0.3, dt * 60);
      current.x += dx * k;
      current.y += dy * k;
      el.style.transform = `translate3d(${current.x - 240}px, ${current.y - 240}px, 0)`;
      /* Settled: park the loop. Repainting a 480px blend layer every
         frame while the pointer rests was a real scroll-lag source. */
      if (dx * dx + dy * dy < 0.04) {
        raf = 0;
        return;
      }
      raf = requestAnimationFrame(tick);
    };

    const wake = () => {
      if (raf === 0) {
        last = performance.now();
        raf = requestAnimationFrame(tick);
      }
    };

    const onMove = (e: PointerEvent) => {
      target.x = e.clientX;
      target.y = e.clientY;
      wake();
      if (!visible) {
        visible = true;
        el.style.opacity = "1";
      }
    };
    const onLeave = () => {
      visible = false;
      el.style.opacity = "0";
    };

    window.addEventListener("pointermove", onMove, { passive: true });
    document.documentElement.addEventListener("pointerleave", onLeave);
    raf = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener("pointermove", onMove);
      document.documentElement.removeEventListener("pointerleave", onLeave);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed top-0 left-0 z-[3] h-[480px] w-[480px] rounded-full opacity-0 mix-blend-screen transition-opacity duration-700 will-change-transform"
      style={{
        background:
          "radial-gradient(circle, rgba(255,0,60,0.08) 0%, transparent 60%)",
      }}
    />
  );
}
