"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Code, Key, MagnifyingGlass } from "@phosphor-icons/react";
import { EASE_ENTER, EASE_TRAVEL } from "@/lib/motion";
import type { HubScript } from "@/lib/hub-data";
import { ZMark, ZWordmark } from "./ZLogo";
import {
  SuggestPanel,
  useHubScripts,
  useScriptSuggestions,
} from "./ScriptSuggest";

export type HubTab = "scripts" | "key";

const TABS: { id: HubTab; label: string; icon: typeof Code }[] = [
  { id: "scripts", label: "Scripts", icon: Code },
  { id: "key", label: "Key System", icon: Key },
];

function Divider({ className = "" }: { className?: string }) {
  return (
    <span
      className={`from-ledz-border/0 via-ledz-border to-ledz-border/0 h-8 w-px self-center bg-gradient-to-b ${className}`}
      aria-hidden="true"
    />
  );
}

export function Header({
  tab,
  onTabChange,
  entered,
  query,
  onQueryChange,
  onPickScript,
}: {
  tab: HubTab;
  onTabChange: (t: HubTab) => void;
  entered: boolean;
  query: string;
  onQueryChange: (q: string) => void;
  onPickScript: (s: HubScript) => void;
}) {
  const [scrolled, setScrolled] = useState(false);
  const scripts = useHubScripts();
  const { items, open, setOpen, active, setActive, trimmed } =
    useScriptSuggestions(query, scripts);
  const showPanel = open && trimmed.length > 0;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={entered ? { opacity: 1, y: 0 } : { opacity: 0, y: -20 }}
      transition={{ duration: 0.55, delay: 0.05, ease: EASE_ENTER }}
      className="sticky top-0 z-40 w-full px-2 pt-0 sm:px-2.5"
    >
      {/* Floating console bar: stretches wider than the content grid,
          rides flush against the very top of the viewport */}
      <div
        className={`hairline-red mx-auto flex w-full max-w-7xl flex-wrap items-center gap-x-4 gap-y-3 rounded-[22px] border px-4 py-2.5 backdrop-blur-xl transition-all duration-300 sm:px-5 ${
          scrolled
            ? "border-ledz-border bg-black/85 shadow-[0_18px_50px_-20px_rgba(0,0,0,0.9)]"
            : "border-ledz-border/60 bg-black/60"
        }`}
      >
        {/* Brand: lifted a touch so the wordmark rides the tab centerline */}
        <button
          type="button"
          onClick={() => onTabChange("scripts")}
          className="group -mt-1 flex shrink-0 cursor-pointer items-center gap-3"
          aria-label="LedZ Hub, back to scripts"
        >
          <span className="border-ledz/40 from-neutral-900 to-black shadow-ledz/25 relative flex h-11 w-11 items-center justify-center rounded-2xl border bg-gradient-to-b shadow-[0_0_20px_-6px_rgba(255,0,60,0.55)] transition-all duration-200 group-hover:border-ledz/70 group-hover:shadow-[0_0_28px_-4px_rgba(255,0,60,0.8)]">
            <ZMark size={26} />
          </span>
          <span className="text-left">
            <ZWordmark />
            <span className="mt-1 block font-mono text-[9px] tracking-[0.25em] text-neutral-500 uppercase">
              Premium Script Hub
            </span>
          </span>
        </button>

        <Divider className="hidden md:block" />

        {/* Tabs */}
        <div
          role="tablist"
          aria-label="Hub sections"
          className="border-ledz-border/80 bg-neutral-950/70 order-last flex w-full items-center justify-center gap-1 rounded-2xl border p-1 shadow-inner md:order-none md:w-auto"
          onKeyDown={(e) => {
            if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
              const next = tab === "scripts" ? "key" : "scripts";
              onTabChange(next);
              document.getElementById(`tab-${next}`)?.focus();
            }
          }}
        >
          {TABS.map(({ id, label, icon: Icon }) => {
            const active = tab === id;
            return (
              <button
                key={id}
                id={`tab-${id}`}
                type="button"
                role="tab"
                aria-selected={active}
                aria-controls={`panel-${id}`}
                onClick={() => onTabChange(id)}
                className={`relative flex min-h-[44px] flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl px-6 py-2 text-sm font-semibold transition-colors duration-200 md:flex-none ${
                  active ? "text-white" : "text-neutral-400 hover:text-white"
                }`}
              >
                {active && (
                  <motion.span
                    layoutId="ledz-tab-pill"
                    className="from-ledz to-ledz-dark shadow-ledz/40 absolute inset-0 rounded-xl bg-gradient-to-b shadow-lg"
                    transition={{ duration: 0.24, ease: EASE_TRAVEL }}
                    aria-hidden="true"
                  />
                )}
                <Icon
                  className={`relative z-10 h-4 w-4 ${active ? "text-white" : "text-ledz"}`}
                  weight="bold"
                  aria-hidden="true"
                />
                <span className="relative z-10">{label}</span>
              </button>
            );
          })}
        </div>

        {/* Right cluster: search */}
        <div className="ml-auto flex items-center gap-3">
          {/* Compact search (desktop) */}
          <div className="group/hs relative hidden lg:block">
            <MagnifyingGlass
              className="group-focus-within/hs:text-ledz pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-neutral-500 transition-colors duration-200"
              weight="bold"
              aria-hidden="true"
            />
            <input
              id="header-search"
              type="text"
              role="combobox"
              value={query}
              onChange={(e) => {
                onQueryChange(e.target.value);
                setActive(-1);
                setOpen(true);
              }}
              onFocus={() => setOpen(true)}
              onBlur={() => setOpen(false)}
              onKeyDown={(e) => {
                if (e.key === "Escape") {
                  onQueryChange("");
                  setOpen(false);
                  return;
                }
                if (!showPanel || items.length === 0) return;
                if (e.key === "ArrowDown") {
                  e.preventDefault();
                  setActive((i) => Math.min(items.length - 1, i + 1));
                } else if (e.key === "ArrowUp") {
                  e.preventDefault();
                  setActive((i) => Math.max(0, i - 1));
                } else if (e.key === "Enter") {
                  const pick = items[active] ?? items[0];
                  if (pick) {
                    e.preventDefault();
                    onPickScript(pick);
                    setOpen(false);
                  }
                }
              }}
              placeholder="Search games"
              aria-label="Search scripts"
              aria-expanded={showPanel}
              aria-controls="header-suggest"
              aria-autocomplete="list"
              aria-activedescendant={
                showPanel && active >= 0
                  ? `header-suggest-opt-${active}`
                  : undefined
              }
              autoComplete="off"
              spellCheck={false}
              className="border-ledz-border focus:border-ledz focus:ring-ledz/40 h-11 w-[220px] rounded-xl border bg-black/70 pr-4 pl-10 text-sm text-white transition-[width,border-color,box-shadow] duration-300 placeholder:text-neutral-500 focus:w-[300px] focus:ring-2 focus:outline-none"
            />
            {showPanel && (
              <SuggestPanel
                items={items}
                query={trimmed}
                activeIndex={active}
                listboxId="header-suggest"
                onPick={(s) => {
                  onPickScript(s);
                  setOpen(false);
                }}
                onHover={setActive}
              />
            )}
          </div>
        </div>
      </div>
    </motion.header>
  );
}
