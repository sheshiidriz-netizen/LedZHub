"use client";

/**
 * The LedZ mark. One confident Z drawn as a single rounded stroke
 * with a dark under-stroke for depth, the brand red gradient core,
 * and a white-hot inner edge, so it reads as a lit neon tube at any
 * size. Thicker outline per owner direction: 8.5 units on a 48 grid.
 */
/*
 * Fixed gradient id. Every ZMark paints the identical gradient, so sharing
 * one id is safe (first def in the DOM wins, all defs are equal), and a
 * constant string keeps server and client markup byte-identical.
 */
const GRADIENT_ID = "ledz-z-gradient";

export function ZMark({
  size = 24,
  glow = true,
  className,
}: {
  size?: number;
  glow?: boolean;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      aria-hidden="true"
      className={className}
      style={
        glow
          ? { filter: "drop-shadow(0 0 10px rgba(255, 0, 60, 0.6))" }
          : undefined
      }
    >
      <defs>
        <linearGradient
          id={GRADIENT_ID}
          x1="10"
          y1="11"
          x2="38"
          y2="37"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#ff5c7a" />
          <stop offset="0.45" stopColor="#ff003c" />
          <stop offset="1" stopColor="#c40031" />
        </linearGradient>
      </defs>

      {/* Depth layer: dark under-stroke offset down */}
      <path
        d="M13.5 16.5H34.5L13.5 33.5H34.5"
        stroke="rgba(120, 0, 30, 0.55)"
        strokeWidth="9.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        transform="translate(0, 1.6)"
      />
      {/* The Z: one continuous neon-red stroke */}
      <path
        d="M13.5 15.5H34.5L13.5 32.5H34.5"
        stroke={`url(#${GRADIENT_ID})`}
        strokeWidth="8.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* White-hot filament running through the stroke center */}
      <path
        d="M13.5 15.5H34.5L13.5 32.5H34.5"
        stroke="rgba(255, 235, 240, 0.5)"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Spark on the top-right terminal */}
      <circle cx="37" cy="12" r="2.3" fill="#ff5c7a" />
    </svg>
  );
}

/**
 * The LedZ Hub wordmark. "LED" in white, the Z lit in brand red,
 * "HUB" set apart in cool silver behind a hairline divider, so the
 * wordmark carries the same hierarchy at every size.
 */
export function ZWordmark({
  className = "",
  compact = false,
}: {
  className?: string;
  compact?: boolean;
}) {
  return (
    <span
      className={`flex items-baseline gap-2 font-bold tracking-tight text-white ${
        compact ? "text-base" : "text-lg leading-none sm:text-xl"
      } ${className}`}
    >
      <span className="tabular" aria-hidden="false">
        LED
        <span className="text-ledz text-glow-red">Z</span>
      </span>
      <span
        className="h-[0.95em] w-px self-center bg-gradient-to-b from-transparent via-white/25 to-transparent"
        aria-hidden="true"
      />
      <span
        className={`font-semibold tracking-[0.28em] text-neutral-400 uppercase ${
          compact ? "text-[10px]" : "text-[11px]"
        }`}
      >
        Hub
      </span>
    </span>
  );
}
