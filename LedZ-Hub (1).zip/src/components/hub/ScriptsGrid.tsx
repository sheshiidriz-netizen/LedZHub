"use client";

import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { Ghost, ArrowCounterClockwise } from "@phosphor-icons/react";
import { filterScripts, type HubScript } from "@/lib/hub-data";
import { ScriptCard } from "./ScriptCard";
import { fetchScriptsResilient, scriptsQueryKey } from "./hub-queries";
import { EASE_ENTER } from "@/lib/motion";

function SkeletonCard() {
  return (
    <div className="border-ledz-border bg-void-raised/70 flex h-[340px] flex-col gap-5 rounded-[24px] border p-6 backdrop-blur-[6px]">
      <div className="flex justify-between">
        <div className="skeleton-shimmer h-6 w-32 rounded-full" />
        <div className="skeleton-shimmer h-4 w-8 rounded-md" />
      </div>
      <div className="skeleton-shimmer h-9 w-2/3 rounded-xl" />
      <div className="skeleton-shimmer min-h-[92px] flex-1 rounded-2xl" />
      <div className="skeleton-shimmer h-12 w-full rounded-2xl" />
    </div>
  );
}

export function ScriptsGrid({
  query,
  onCopy,
  onClear,
}: {
  query: string;
  onCopy: (script: HubScript) => void;
  onClear: () => void;
}) {
  const { data, isLoading } = useQuery({
    queryKey: scriptsQueryKey,
    queryFn: fetchScriptsResilient,
  });

  const scripts = data?.scripts ?? [];
  const filtered = useMemo(
    () => filterScripts(scripts, query),
    [scripts, query]
  );

  if (isLoading) {
    return (
      <div
        className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3"
        aria-busy="true"
        aria-label="Loading scripts"
      >
        {Array.from({ length: 6 }, (_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    );
  }

  if (filtered.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: EASE_ENTER }}
        className="card-wash border-ledz-border bg-void-raised/70 space-y-4 rounded-[24px] border py-16 text-center backdrop-blur-[6px]"
      >
        <Ghost className="mx-auto h-10 w-10 text-neutral-600" weight="bold" aria-hidden="true" />
        <div className="space-y-1.5 px-6">
          <p className="text-lg font-bold text-white">Nothing in the void</p>
          <p className="font-mono text-xs leading-relaxed text-neutral-500">
            No scripts match <span className="text-ledz">{query}</span>. Try
            another game name.
          </p>
        </div>
        <button
          type="button"
          onClick={onClear}
          className="border-ledz-border text-neutral-300 hover:border-ledz/60 hover:bg-ledz/10 hover:text-white mx-auto flex h-11 cursor-pointer items-center gap-2 rounded-full border px-5 font-mono text-[11px] font-bold tracking-[0.15em] uppercase transition-all duration-200"
        >
          <ArrowCounterClockwise className="h-3.5 w-3.5" weight="bold" aria-hidden="true" />
          Clear search
        </button>
      </motion.div>
    );
  }

  return (
    <motion.div
      layout
      className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3"
      transition={{ duration: 0.3, ease: EASE_ENTER }}
    >
      <AnimatePresence mode="popLayout" initial={false}>
        {filtered.map((script, i) => (
          <ScriptCard
            key={script.id}
            script={script}
            index={i}
            onCopy={onCopy}
          />
        ))}
      </AnimatePresence>
    </motion.div>
  );
}
