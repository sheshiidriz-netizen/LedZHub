"use client";

import { MagnifyingGlass, X } from "@phosphor-icons/react";
import type { HubScript } from "@/lib/hub-data";
import { Reveal } from "./Reveal";
import {
  SuggestPanel,
  useScriptSuggestions,
} from "./ScriptSuggest";

/**
 * Centered hero. The 3D monogram sits above the headline, the
 * WebGPU shader breathes behind everything, and the script counter
 * under the search bar is real: the count comes from the live API
 * response, so the hub never claims more than it holds.
 */
export function HeroBanner({
  entered,
  query,
  onQueryChange,
  onPickScript,
  scripts,
  total,
  showing,
}: {
  entered: boolean;
  query: string;
  onQueryChange: (q: string) => void;
  onPickScript: (s: HubScript) => void;
  scripts: HubScript[];
  total: number;
  showing: number;
}) {
  const { items, open, setOpen, active, setActive, trimmed } =
    useScriptSuggestions(query, scripts);
  const showPanel = open && trimmed.length > 0;

  return (
    <section className="panel-frame relative mx-auto max-w-3xl overflow-hidden rounded-[28px] px-6 py-8 text-center sm:px-8 sm:py-10">
      {/* Always-on black & red void: pure CSS, renders on every device
          at zero GPU cost. Same palette the WebGPU layer used to add. */}
      <div className="hero-void pointer-events-none absolute inset-0" aria-hidden="true" />
      {/* Hairline light along the top edge */}
      <div
        className="from-ledz/0 via-ledz/50 to-ledz/0 pointer-events-none absolute inset-x-8 top-0 h-px bg-gradient-to-r"
        aria-hidden="true"
      />

      <div className="relative z-10 mx-auto flex max-w-2xl flex-col items-center space-y-5">
        {/* 3D monogram */}
        <Reveal active={entered} delay={0.05}>
          <Z3DMount />
        </Reveal>

        {/* Headline */}
        <h1 className="text-5xl leading-[1.05] font-bold tracking-tight text-balance uppercase sm:text-6xl">
          <span className={`mask-line ${entered ? "mask-in" : ""}`}>
            <span className="text-gradient-silver mask-word">One hub.</span>
          </span>{" "}
          <span className={`mask-line ${entered ? "mask-in" : ""}`}>
            <span
              className="text-shimmer-red mask-word"
              style={{ transitionDelay: "90ms" }}
            >
              Every script.
            </span>
          </span>
        </h1>

        <Reveal active={entered} delay={0.22}>
          <p className="max-w-xl text-pretty text-sm leading-relaxed text-neutral-400 sm:text-base">
            Every loadstring in the hub is hand tested and unlocked with one
            universal key. Copy it, paste it into your executor, run it. No
            ads, no link shorteners, no key farms.
          </p>
        </Reveal>

        {/* Search, centered */}
        <Reveal active={entered} delay={0.3} className="w-full max-w-xl">
          <div className="group/bar relative">
            <div
              className="bg-ledz/0 group-focus-within/bar:bg-ledz pointer-events-none absolute -inset-1 rounded-[22px] opacity-0 blur-lg transition-all duration-300 group-focus-within/bar:opacity-20"
              aria-hidden="true"
            />
            <MagnifyingGlass
              className="group-focus-within/bar:text-ledz pointer-events-none absolute top-1/2 left-5 z-10 h-[18px] w-[18px] -translate-y-1/2 text-neutral-500 transition-colors duration-200"
              weight="bold"
              aria-hidden="true"
            />
            <input
              id="script-search"
              type="text"
              role="combobox"
              value={query}
              onChange={(e) => {
                onQueryChange(e.target.value);
                setActive(-1);
                setOpen(true);
              }}
              onFocus={() => setOpen(true)}
              onBlur={() => setOpen(false)}
              onKeyDown={(e) => {
                if (e.key === "Escape") {
                  onQueryChange("");
                  setOpen(false);
                  return;
                }
                if (!showPanel || items.length === 0) return;
                if (e.key === "ArrowDown") {
                  e.preventDefault();
                  setActive((i) => Math.min(items.length - 1, i + 1));
                } else if (e.key === "ArrowUp") {
                  e.preventDefault();
                  setActive((i) => Math.max(0, i - 1));
                } else if (e.key === "Enter") {
                  const pick = items[active] ?? items[0];
                  if (pick) {
                    e.preventDefault();
                    onPickScript(pick);
                    setOpen(false);
                  }
                }
              }}
              placeholder="Search a game, like Blox Strike or MM2"
              aria-label="Search scripts by game"
              aria-expanded={showPanel}
              aria-controls="hero-suggest"
              aria-autocomplete="list"
              aria-activedescendant={
                showPanel && active >= 0
                  ? `hero-suggest-opt-${active}`
                  : undefined
              }
              autoComplete="off"
              spellCheck={false}
              className="border-[#2b2b3a] focus:border-ledz/70 focus:ring-ledz/40 relative h-14 w-full rounded-2xl border bg-black/85 pr-14 pl-13 text-sm text-white shadow-inner transition-all duration-200 placeholder:text-neutral-500 focus:ring-2 focus:outline-none"
            />
            {query ? (
              <button
                type="button"
                onClick={() => onQueryChange("")}
                aria-label="Clear search"
                className="border-ledz-border text-neutral-400 hover:border-ledz/60 hover:text-ledz absolute top-1/2 right-3 z-10 flex h-8 w-8 -translate-y-1/2 cursor-pointer items-center justify-center rounded-xl border transition-colors duration-150"
              >
                <X className="h-4 w-4" weight="bold" aria-hidden="true" />
              </button>
            ) : null}
            {showPanel && (
              <SuggestPanel
                items={items}
                query={trimmed}
                activeIndex={active}
                listboxId="hero-suggest"
                onPick={(s) => {
                  onPickScript(s);
                  setOpen(false);
                }}
                onHover={setActive}
              />
            )}
          </div>
          <p
            className="mt-3 font-mono text-xs tracking-[0.2em] text-neutral-500 uppercase tabular"
            aria-live="polite"
          >
            {query
              ? `Showing ${String(showing).padStart(2, "0")} of ${total} scripts`
              : `${total} scripts in the hub`}
          </p>
        </Reveal>
      </div>
    </section>
  );
}

/* Client-only island: the three.js monogram */
import dynamic from "next/dynamic";
const Z3DMount = dynamic(() => import("./ZMonogram3D"), { ssr: false });
