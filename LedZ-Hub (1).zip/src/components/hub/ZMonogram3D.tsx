"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

/**
 * The LedZ monogram in real 3D: ONE continuous slab cut from the exact
 * outline of the 2D wordmark, so every joint is a true edge-to-edge
 * meeting and no volume ever intersects another. The slab is beveled,
 * its corners are rounded, and real neon tubes (TubeGeometry, not
 * hairlines) trace the front and back silhouette, so the outline reads
 * thick from any angle. A spark node pulses on the top-right terminal,
 * matching the 2D mark. It breathes slowly and tilts toward the pointer.
 */

/* The Z outline on the 48-grid of the 2D mark (wordmark path
 * M13.5 15.5 H34.5 L13.5 32.5 H34.5 with an 8.5 stroke, square caps).
 * Each point below is an exact edge-to-edge intersection of the strokes:
 * no overlapping volumes, so the extruded slab is watertight. */
const OUTLINE_SVG: ReadonlyArray<readonly [number, number]> = [
  [9.25, 11.25], // top bar, left, top
  [38.75, 11.25], // top bar, right, top
  [38.75, 17.524], // miter: right end meets the diagonal's outer edge
  [25.498, 28.25], // diagonal's outer edge meets the bottom bar's top edge
  [38.75, 28.25], // bottom bar, right, top
  [38.75, 36.75], // bottom bar, right, bottom
  [9.25, 36.75], // bottom bar, left, bottom
  [9.25, 28.25], // bottom bar, left, top
  [12.001, 28.25], // bottom bar's top edge meets the diagonal's inner edge
  [22.503, 19.75], // diagonal's inner edge meets the top bar's bottom edge
  [9.25, 19.75], // top bar, left, bottom
];

const SCALE = 0.095; // 48-grid units -> world units
const CENTER = 24; // the outline is centered on the grid
const CORNER_R = 0.075; // corner rounding of the slab
const DEPTH = 0.6; // slab thickness
const BEVEL = 0.055; // bevel depth on both faces
const TUBE_R = 0.068; // neon tube radius (thick, real geometry)
const CORE_R = 0.026; // white-hot filament riding the front tube

function toWorld(p: readonly [number, number]): THREE.Vector2 {
  return new THREE.Vector2(
    (p[0] - CENTER) * SCALE,
    (CENTER - p[1]) * SCALE
  );
}

interface Corner {
  a: THREE.Vector2;
  b: THREE.Vector2;
  c: THREE.Vector2;
}

/** Round every polygon corner: entry point `a`, vertex `c`, exit point `b`. */
function roundedCorners(pts: THREE.Vector2[], r: number): Corner[] {
  const n = pts.length;
  const at = (i: number) => pts[(i + n) % n];
  return pts.map((_, i) => {
    const prev = at(i - 1);
    const cur = at(i);
    const next = at(i + 1);
    const toPrev = prev.clone().sub(cur);
    const toNext = next.clone().sub(cur);
    const rp = Math.min(r, toPrev.length() * 0.5);
    const rn = Math.min(r, toNext.length() * 0.5);
    const a = cur.clone().add(toPrev.normalize().multiplyScalar(rp));
    const b = cur.clone().add(toNext.normalize().multiplyScalar(rn));
    return { a, b, c: cur.clone() };
  });
}

/** The rounded outline as a 2D shape for extrusion. */
function roundedShape(corners: Corner[]): THREE.Shape {
  const shape = new THREE.Shape();
  const n = corners.length;
  corners.forEach(({ a, b, c }, i) => {
    const prevExit = corners[(i - 1 + n) % n].b;
    if (i === 0) shape.moveTo(prevExit.x, prevExit.y);
    shape.lineTo(a.x, a.y);
    shape.quadraticCurveTo(c.x, c.y, b.x, b.y);
  });
  shape.closePath();
  return shape;
}

/** The same rounded outline as a closed 3D curve at depth z (neon tube path). */
function roundedContour(
  corners: Corner[],
  z: number
): THREE.CurvePath<THREE.Vector3> {
  const path = new THREE.CurvePath<THREE.Vector3>();
  const v3 = (p: THREE.Vector2) => new THREE.Vector3(p.x, p.y, z);
  const n = corners.length;
  corners.forEach(({ a, b, c }, i) => {
    const prevExit = corners[(i - 1 + n) % n].b;
    path.add(new THREE.LineCurve3(v3(prevExit), v3(a)));
    path.add(
      new THREE.QuadraticBezierCurve3(v3(a), v3(c), v3(b))
    );
  });
  return path;
}

function ZGroup() {
  const group = useRef<THREE.Group>(null);
  const tubeMat = useRef<THREE.MeshBasicMaterial>(null);
  const bodyMat = useRef<THREE.MeshStandardMaterial>(null);
  const spark = useRef<THREE.Mesh>(null);
  const pointer = useRef({ x: 0, y: 0 });
  const reduced = useMemo(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    []
  );

  const built = useMemo(() => {
    const pts = OUTLINE_SVG.map(toWorld);
    const corners = roundedCorners(pts, CORNER_R);

    const bodyGeo = new THREE.ExtrudeGeometry(roundedShape(corners), {
      depth: DEPTH,
      bevelEnabled: true,
      bevelThickness: BEVEL,
      bevelSize: BEVEL * 0.9,
      bevelOffset: 0,
      bevelSegments: 3,
      curveSegments: 8,
    });
    bodyGeo.translate(0, 0, -DEPTH / 2);

    const frontGeo = new THREE.TubeGeometry(
      roundedContour(corners, DEPTH / 2),
      240,
      TUBE_R,
      12,
      true
    );
    const backGeo = new THREE.TubeGeometry(
      roundedContour(corners, -DEPTH / 2),
      240,
      TUBE_R,
      12,
      true
    );
    // White-hot filament riding the front tube, like the 2D mark's core.
    // Offset outward just enough to poke through the red tube's surface.
    const coreGeo = new THREE.TubeGeometry(
      roundedContour(corners, DEPTH / 2 + TUBE_R + CORE_R * 0.2),
      240,
      CORE_R,
      10,
      true
    );

    // Spark node on the top-right terminal of the outline.
    const topRight = corners[1].c; // vertex of the top bar's right, top
    const sparkGeo = new THREE.SphereGeometry(0.085, 20, 20);
    const sparkPos = new THREE.Vector3(
      topRight.x - TUBE_R * 0.25,
      topRight.y - TUBE_R * 0.25,
      DEPTH / 2
    );

    return { bodyGeo, frontGeo, backGeo, coreGeo, sparkGeo, sparkPos };
  }, []);

  useEffect(() => {
    return () => {
      built.bodyGeo.dispose();
      built.frontGeo.dispose();
      built.backGeo.dispose();
      built.coreGeo.dispose();
      built.sparkGeo.dispose();
    };
  }, [built]);

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      pointer.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.current.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, []);

  useFrame((state, rawDelta) => {
    const g = group.current;
    if (!g) return;

    if (reduced) {
      g.rotation.set(0.28, -0.42, 0);
      return;
    }

    const t = state.clock.elapsedTime;
    const dt = Math.min(rawDelta || 1 / 60, 0.05);
    /* Frame-rate independent tilt: k reaches the same response at any
       refresh rate. 0.16 base factor reads as an immediate, weighty
       follow instead of a sluggish drift. */
    const k = 1 - Math.pow(1 - 0.16, dt * 60);

    // Tilt toward the pointer plus a slow float.
    g.rotation.y += (pointer.current.x * 0.72 - 0.42 - g.rotation.y) * k;
    g.rotation.x += (0.28 - pointer.current.y * 0.34 - g.rotation.x) * k;
    g.position.y = Math.sin(t * 0.8) * 0.08;
    g.rotation.z = Math.sin(t * 0.4) * 0.015;

    // Neon breathing: the tubes glow a touch hotter, the body hums along.
    const pulse = 0.5 + 0.5 * Math.sin(t * 2.1);
    if (tubeMat.current) {
      tubeMat.current.color.setRGB(
        1,
        0.04 + 0.18 * pulse,
        0.27 + 0.14 * pulse
      );
    }
    if (bodyMat.current) {
      bodyMat.current.emissiveIntensity = 0.07 + 0.06 * pulse;
    }
    if (spark.current) {
      const s = 1 + 0.22 * Math.sin(t * 3.2);
      spark.current.scale.setScalar(s);
    }
  });

  return (
    <group ref={group} rotation={[0.28, -0.42, 0]}>
      {/* One continuous obsidian slab with a faint red core */}
      <mesh geometry={built.bodyGeo}>
        <meshStandardMaterial
          ref={bodyMat}
          color="#120208"
          metalness={0.7}
          roughness={0.26}
          emissive="#ff003c"
          emissiveIntensity={0.07}
        />
      </mesh>

      {/* Neon tubes tracing the front and back silhouettes */}
      <mesh geometry={built.frontGeo}>
        <meshBasicMaterial color="#ff0a45" toneMapped={false} ref={tubeMat} />
      </mesh>
      <mesh geometry={built.backGeo}>
        <meshBasicMaterial color="#ff0a45" toneMapped={false} />
      </mesh>

      {/* White-hot filament riding the front tube */}
      <mesh geometry={built.coreGeo}>
        <meshBasicMaterial color="#ffd9e2" toneMapped={false} />
      </mesh>

      {/* Spark node on the top-right terminal */}
      <mesh geometry={built.sparkGeo} position={built.sparkPos} ref={spark}>
        <meshBasicMaterial color="#ffb3c4" toneMapped={false} />
      </mesh>
    </group>
  );
}

export default function ZMonogram3D({ size = 128 }: { size?: number }) {
  const reduced =
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* Offscreen: the hero canvas kept rendering while users were reading
     the grid below, which is exactly where the scroll lag came from. */
  const hostRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const el = hostRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      ([entry]) => setVisible(entry.isIntersecting),
      { rootMargin: "80px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      ref={hostRef}
      className="relative select-none"
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      {/* Soft red pool of light under the mark */}
      <div
        className="absolute inset-[24%] rounded-full"
        style={{
          background:
            "radial-gradient(circle, rgba(255,0,60,0.22) 0%, transparent 65%)",
          filter: "blur(14px)",
        }}
      />
      <Canvas
        camera={{ position: [0, 0, 5.4], fov: 42 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true }}
        frameloop={reduced || !visible ? "never" : "always"}
      >
        <ambientLight intensity={0.34} />
        <pointLight position={[3, 3.4, 4]} intensity={34} color="#ff003c" />
        <pointLight position={[-4, -2, 3]} intensity={10} color="#ffffff" />
        <pointLight position={[0, -4, -4]} intensity={8} color="#ff5c7a" />
        <ZGroup />
      </Canvas>
    </div>
  );
}
