"use client";

import {
  SCRIPTS,
  KEY_INFO,
  type HubScript,
  type KeyResponse,
  type ScriptsResponse,
} from "@/lib/hub-data";

export const scriptsQueryKey = ["ledz-scripts"] as const;
export const keyQueryKey = ["ledz-key"] as const;

/**
 * Resilient fetchers — the UI never breaks: if the API route or the
 * Rust upstream is unreachable, the embedded database answers instead.
 */
export async function fetchScriptsResilient(): Promise<ScriptsResponse> {
  try {
    const res = await fetch("/api/scripts");
    if (!res.ok) throw new Error(`status ${res.status}`);
    return (await res.json()) as ScriptsResponse;
  } catch {
    return {
      source: "next-runtime",
      total: SCRIPTS.length,
      generated_at: "",
      scripts: SCRIPTS,
    };
  }
}

export async function fetchKeyResilient(): Promise<KeyResponse> {
  try {
    const res = await fetch("/api/key");
    if (!res.ok) throw new Error(`status ${res.status}`);
    return (await res.json()) as KeyResponse;
  } catch {
    return {
      source: "next-runtime",
      label: KEY_INFO.label,
      key: KEY_INFO.key,
      status: KEY_INFO.status,
      active: KEY_INFO.active,
      updated_at: "",
    };
  }
}

export interface SuggestResponse {
  source: "rust-core" | "next-runtime";
  query: string;
  total: number;
  scripts: HubScript[];
}

/** Ranked search suggestions; served by the DB with the Rust core as
 *  a fallback tier. */
export async function fetchSuggest(q: string): Promise<SuggestResponse> {
  const res = await fetch(`/api/scripts/search?q=${encodeURIComponent(q)}`);
  if (!res.ok) throw new Error(`status ${res.status}`);
  return (await res.json()) as SuggestResponse;
}
