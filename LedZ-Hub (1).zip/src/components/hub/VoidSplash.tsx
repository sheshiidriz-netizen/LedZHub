"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { FastForward } from "@phosphor-icons/react";
import { EASE_ENTER } from "@/lib/motion";
import { ZMark } from "./ZLogo";

type Phase = "loading" | "welcome" | "done";

const STATUS_LINES = [
  "WAKING THE VOID CORE…",
  "LINKING EXECUTOR PROTOCOLS…",
  "DECRYPTING SCRIPT HUB…",
  "CALIBRATING NEON GRID…",
  "VOID CORE ONLINE",
] as const;

const FULL_DURATION = 2200;
const WELCOME_HOLD = 1400;

export default function VoidSplash({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<Phase>("loading");
  const [progress, setProgress] = useState(0);
  const doneRef = useRef(false);

  const finish = () => {
    if (doneRef.current) return;
    doneRef.current = true;
    setPhase("done");
    onComplete();
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const forced = params.get("intro") === "force";
    const skipped = params.get("intro") === "0";
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const seen = sessionStorage.getItem("ledz-void-intro");
    const quick = skipped || reduced || (!forced && seen === "1");

    if (quick) {
      sessionStorage.setItem("ledz-void-intro", "1");
      const t1 = setTimeout(() => setPhase("welcome"), 180);
      const t2 = setTimeout(finish, 800);
      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
      };
    }

    sessionStorage.setItem("ledz-void-intro", "1");
    let raf = 0;
    const t0 = performance.now();

    const tick = (t: number) => {
      const raw = Math.min(1, (t - t0) / FULL_DURATION);
      const eased = raw * raw * (3 - 2 * raw); // smoothstep
      setProgress(eased * 100);
      if (raw < 1) {
        raf = requestAnimationFrame(tick);
        return;
      }
      setProgress(100);
      setPhase("welcome");
      setTimeout(finish, WELCOME_HOLD);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const statusIndex =
    progress >= 100
      ? 4
      : progress >= 75
        ? 3
        : progress >= 50
          ? 2
          : progress >= 25
            ? 1
            : 0;

  /* Cube breathes in as the core charges: 0.86 → 1.06 over the load. */
  const cubeScale = 0.86 + (progress / 100) * 0.2;
  const welcoming = phase === "welcome";

  return (
    <motion.div
      className="fixed inset-0 z-100 flex flex-col items-center justify-center overflow-hidden bg-void-deep"
      exit={{ opacity: 0, scale: 1.02, filter: "blur(8px)" }}
      transition={{ duration: 0.9, ease: EASE_ENTER }}
    >
      <div className="void-aura" aria-hidden="true" />

      <div className="relative z-20 flex flex-col items-center space-y-7 px-4 text-center">
        {/* 3D Z cube + orbit rings — recedes gently once loading completes */}
        <motion.div
          className="relative my-3"
          initial={{ opacity: 0, scale: 0.6 }}
          animate={{
            opacity: 1,
            scale: 1,
            ...(welcoming ? { opacity: 0.35, scale: 0.94 } : {}),
          }}
          transition={{ duration: 0.6, ease: EASE_ENTER }}
        >
          <motion.div
            className="relative"
            animate={{ scale: cubeScale }}
            transition={{ duration: 0.18, ease: "linear" }}
          >
            <div className="orbit-ring o1" aria-hidden="true" />
            <div className="orbit-ring o2" aria-hidden="true" />
            <div className="h-[100px] w-[100px]">
              <div className="cube-3d">
                <div className="cube-face face-front"><ZMark size={52} /></div>
                <div className="cube-face face-back"><ZMark size={52} /></div>
                <div className="cube-face face-right"><ZMark size={52} /></div>
                <div className="cube-face face-left"><ZMark size={52} /></div>
                <div className="cube-face face-top"><ZMark size={52} /></div>
                <div className="cube-face face-bottom"><ZMark size={52} /></div>
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* Title → crossfades into a calm "Welcome." */}
        <div className="relative flex w-full items-center justify-center">
          <motion.div
            className="space-y-3"
            animate={{
              opacity: welcoming ? 0 : 1,
              y: welcoming ? -8 : 0,
              filter: welcoming ? "blur(6px)" : "blur(0px)",
            }}
            transition={{ duration: 0.55, ease: EASE_ENTER }}
          >
            <h1 className="flex items-baseline justify-center gap-3 text-4xl font-bold tracking-tight text-white uppercase sm:text-5xl">
              <span>
                LED<span className="text-ledz text-glow-red">Z</span>
              </span>
              <span
                className="h-[0.9em] w-px self-center bg-gradient-to-b from-transparent via-white/25 to-transparent"
                aria-hidden="true"
              />
              <span className="text-[0.55em] font-semibold tracking-[0.32em] text-neutral-400">
                HUB
              </span>
            </h1>
            <p
              className="min-h-4 font-mono text-xs tracking-widest text-neutral-400 uppercase"
              role="status"
              aria-live="polite"
            >
              {STATUS_LINES[statusIndex]}
            </p>
          </motion.div>

          <AnimatePresence>
            {welcoming && (
              <motion.p
                className="absolute inset-0 flex items-center justify-center"
                initial={{ opacity: 0, y: 10, filter: "blur(8px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{ duration: 0.7, ease: EASE_ENTER, delay: 0.25 }}
              >
                <span className="text-3xl font-light tracking-[0.06em] text-white sm:text-4xl">
                  Welcome<span className="text-ledz">.</span>
                </span>
              </motion.p>
            )}
          </AnimatePresence>
        </div>

        {/* Loader — quietly steps aside when done */}
        <AnimatePresence>
          {phase === "loading" && (
            <motion.div
              className="w-64 space-y-2.5 sm:w-80"
              exit={{ opacity: 0, y: 6, filter: "blur(4px)" }}
              transition={{ duration: 0.45, ease: EASE_ENTER }}
            >
              <div className="h-2.5 w-full overflow-hidden rounded-full border border-ledz-border bg-neutral-900 p-0.5">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-red-800 to-ledz shadow-lg shadow-ledz/50"
                  style={{ width: `${progress}%`, transition: "width 90ms linear" }}
                />
              </div>
              <div className="flex items-center justify-between px-1 font-mono text-[11px] font-bold text-neutral-400">
                <span>LOADING CORE</span>
                <span className="tabular text-ledz text-glow-red">
                  {Math.floor(progress)}%
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Skip */}
      {phase === "loading" && (
        <motion.button
          type="button"
          onClick={finish}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.4 }}
          className="text-neutral-400 hover:text-ledz group absolute bottom-8 left-1/2 flex -translate-x-1/2 cursor-pointer items-center gap-2 font-mono text-[11px] font-bold tracking-[0.25em] uppercase transition-colors duration-200"
        >
          Skip intro
          <FastForward
            className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5"
            weight="bold"
            aria-hidden="true"
          />
        </motion.button>
      )}
    </motion.div>
  );
}
