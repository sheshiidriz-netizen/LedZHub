import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-6 px-6 text-center">
      <p className="text-ledz text-glow-red font-mono text-7xl font-bold tabular">
        404
      </p>
      <div className="space-y-2">
        <h1 className="text-2xl font-bold tracking-tight text-white uppercase">
          Lost in the void
        </h1>
        <p className="max-w-sm text-sm leading-relaxed text-neutral-400">
          This page does not exist. The hub, the key system, and every script
          are still where you left them.
        </p>
      </div>
      <Link
        href="/"
        className="btn-primary btn-sheen flex h-12 items-center justify-center rounded-2xl px-7 text-sm font-bold tracking-[0.12em] text-white uppercase"
      >
        Back to the hub
      </Link>
    </main>
  );
}
