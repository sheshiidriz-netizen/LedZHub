import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

/* Geist: sharp, contemporary foundry face for a professional product
   surface. Geist Mono only for code, keys, and numeric data. */
const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "LedZ Hub · Script Hub",
  description:
    "One hub. Every script. A hand-picked collection of premium Roblox scripts behind a single universal key: copy loadstrings, activate LedZKey, dominate every game.",
  keywords: ["LedZ Hub", "Roblox", "scripts", "loadstring", "LedZKey", "executor"],
  icons: { icon: "/ledz.svg" },
  openGraph: {
    title: "LedZ Hub · Script Hub",
    description: "One hub. Every script. Black & red. Zero compromise.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#050507",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} font-sans antialiased bg-void text-foreground overflow-x-hidden`}
      >
        {children}
        <Toaster position="bottom-center" />
      </body>
    </html>
  );
}
