import type { Metadata } from "next";
import AdminPanel from "@/components/admin/AdminPanel";

export const metadata: Metadata = {
  title: "LedZ Hub · Admin",
  description: "Manage the LedZ Hub script hub.",
  robots: { index: false, follow: false },
};

export default function PostPage() {
  return <AdminPanel />;
}
