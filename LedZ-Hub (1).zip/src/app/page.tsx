import HubShell from "@/components/hub/HubShell";

export default function Home() {
  return <HubShell />;
}
