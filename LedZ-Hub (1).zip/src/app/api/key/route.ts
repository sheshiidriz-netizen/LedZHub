import { KEY_INFO, type KeyResponse } from "@/lib/hub-data";

export const revalidate = 60;

/**
 * GET /api/key
 * Universal activation key. Same upstream-first strategy as /api/scripts.
 */
export async function GET() {
  const upstream = process.env.LEDZ_API_URL;

  if (upstream) {
    try {
      const res = await fetch(`${upstream}/api/key`, {
        next: { revalidate: 60 },
        signal: AbortSignal.timeout(2000),
        headers: { accept: "application/json" },
      });
      if (res.ok) {
        const data = (await res.json()) as KeyResponse;
        return Response.json(data);
      }
    } catch {
      // Upstream unreachable — fall through to the local runtime.
    }
  }

  const payload: KeyResponse = {
    source: "next-runtime",
    label: KEY_INFO.label,
    key: KEY_INFO.key,
    status: KEY_INFO.status,
    active: KEY_INFO.active,
    updated_at: new Date().toISOString(),
  };

  return Response.json(payload);
}
