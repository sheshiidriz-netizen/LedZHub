export const dynamic = "force-dynamic";

/**
 * GET /api/health
 * Liveness probe. Reports whether the Rust core is wired in as the
 * upstream for data endpoints or whether the Next.js runtime is
 * serving them locally.
 */
export async function GET() {
  const upstream = process.env.LEDZ_API_URL;
  let upstreamStatus: "disabled" | "online" | "unreachable" = "disabled";

  if (upstream) {
    try {
      const res = await fetch(`${upstream}/api/health`, {
        signal: AbortSignal.timeout(1500),
        headers: { accept: "application/json" },
      });
      upstreamStatus = res.ok ? "online" : "unreachable";
    } catch {
      upstreamStatus = "unreachable";
    }
  }

  return Response.json({
    status: "ok",
    service: "ledz-hub-web",
    version: "2.0.0-void",
    upstream: upstreamStatus,
    time: new Date().toISOString(),
  });
}
