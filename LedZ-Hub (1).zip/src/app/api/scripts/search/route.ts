import { db } from "@/lib/db";
import { SCRIPTS, rankScripts } from "@/lib/hub-data";
import { toHub } from "@/lib/admin-scripts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const RUST_URL = process.env.LEDZ_API_URL;

interface SuggestPayload {
  source: "rust-core" | "next-runtime";
  query: string;
  total: number;
  scripts: ReturnType<typeof toHub>[];
}

/**
 * Optional top tier: the Rust core answers ranked search from memory
 * in well under a millisecond. Used when the database is unreachable,
 * and always available directly at LEDZ_API_URL.
 */
async function rustSearch(q: string, limit: number): Promise<SuggestPayload | null> {
  if (!RUST_URL) return null;
  try {
    // The Rust core runs ranked search at /api/scripts/search; hitting
    // /api/scripts here would return the whole catalog unfiltered.
    const res = await fetch(
      `${RUST_URL}/api/scripts/search?q=${encodeURIComponent(q)}&limit=${limit}`,
      { signal: AbortSignal.timeout(700), cache: "no-store" }
    );
    if (!res.ok) return null;
    const data = (await res.json()) as {
      scripts?: { id: string; title: string; category: string; code: string }[];
    };
    if (!Array.isArray(data.scripts)) return null;
    return {
      source: "rust-core",
      query: q,
      total: data.scripts.length,
      scripts: data.scripts.map((s) => ({
        ...s,
        status: "working" as const,
        badges: [],
      })),
    };
  } catch {
    return null;
  }
}

/**
 * GET /api/scripts/search?q=term&limit=8
 *
 * Ranked suggestions for the search dropdowns. The database is the
 * source of truth (so brand-new admin scripts appear instantly); the
 * Rust core is the second tier, the embedded list the last resort.
 * Ranking matches the client-side rankScripts order, so the instant
 * local results and the server results never reshuffle under the user.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const q = (url.searchParams.get("q") ?? "").trim();
  const limitParam = Number(url.searchParams.get("limit") ?? 8);
  const limit = Number.isFinite(limitParam)
    ? Math.min(50, Math.max(1, Math.floor(limitParam)))
    : 8;

  if (!q) {
    const empty: SuggestPayload = {
      source: "next-runtime",
      query: "",
      total: 0,
      scripts: [],
    };
    return Response.json(empty);
  }

  try {
    // Fetch the whole (small, curated) catalog and rank in memory with
    // the shared scorer: a SQL `contains` prefilter would silently drop
    // acronym matches like "mm2" → "Murder Mystery 2", and the three
    // tiers (local, DB, Rust core) must always agree.
    const rows = await db.script.findMany({
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    });

    // Re-rank with the shared scoring so prefix matches come first.
    const scripts = rankScripts(rows.map(toHub), q, limit);
    const payload: SuggestPayload = {
      source: "next-runtime",
      query: q,
      total: scripts.length,
      scripts,
    };
    return Response.json(payload);
  } catch {
    const rust = await rustSearch(q, limit);
    if (rust) return Response.json(rust);

    const scripts = rankScripts(SCRIPTS, q, limit);
    const payload: SuggestPayload = {
      source: "next-runtime",
      query: q,
      total: scripts.length,
      scripts,
    };
    return Response.json(payload);
  }
}
