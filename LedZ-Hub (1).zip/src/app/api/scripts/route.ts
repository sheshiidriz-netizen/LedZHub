import { db } from "@/lib/db";
import { SCRIPTS, type ScriptsResponse } from "@/lib/hub-data";
import { toHub } from "@/lib/admin-scripts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/scripts
 * The database is the source of truth: every script added or edited
 * in the admin panel appears here immediately, and `total` always
 * counts the real rows. The embedded list is only a last-resort
 * fallback if the database is unreachable.
 */
export async function GET() {
  try {
    const rows = await db.script.findMany({
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    });

    const payload: ScriptsResponse = {
      source: "next-runtime",
      total: rows.length,
      generated_at: new Date().toISOString(),
      scripts: rows.map(toHub),
    };
    return Response.json(payload);
  } catch {
    // Database unreachable: answer from the embedded list so the hub
    // stays usable. The count still matches what is served.
    const payload: ScriptsResponse = {
      source: "next-runtime",
      total: SCRIPTS.length,
      generated_at: new Date().toISOString(),
      scripts: SCRIPTS,
    };
    return Response.json(payload);
  }
}
