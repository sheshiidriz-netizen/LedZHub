import { NextResponse } from "next/server";
import { hasAdminSession } from "@/lib/admin-auth";
import { clientIp, peekRateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

/** Window sizes, mirroring the limits the guarded routes enforce. */
const LOGIN_LIMIT = 5;
const WRITE_LIMIT = 30;
const READ_LIMIT = 30;

/**
 * GET /api/admin/session: cheap poll used by the admin gate.
 *
 * The response carries the real, server-persisted lock windows so the
 * panel can never be surprised by a 429:
 *   - `loginRetryAfter`: the login gate countdown (unauthenticated).
 *   - `writeRetryAfter` / `readRetryAfter`: the action countdowns
 *     (authenticated). Without these, a refresh right after a lock
 *     would look unlocked, invite one more click, and only then hit
 *     the 429. Now the buttons come back already counting down.
 */
export async function GET(req: Request) {
  const authed = hasAdminSession(req);
  const ip = clientIp(req);

  if (!authed) {
    const loginRetryAfter = await peekRateLimit("admin-login", ip, LOGIN_LIMIT);
    return NextResponse.json({ authed, loginRetryAfter });
  }

  const [writeRetryAfter, readRetryAfter] = await Promise.all([
    peekRateLimit("admin-write", ip, WRITE_LIMIT),
    peekRateLimit("admin-read", ip, READ_LIMIT),
  ]);
  return NextResponse.json({
    authed,
    loginRetryAfter: 0,
    writeRetryAfter,
    readRetryAfter,
  });
}
