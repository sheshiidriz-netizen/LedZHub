import { NextResponse } from "next/server";
import {
  ADMIN_COOKIE,
  createSessionToken,
  verifyAdminPassword,
} from "@/lib/admin-auth";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

/**
 * POST /api/admin/login
 * Body: { "password": string }
 *
 * 5 attempts per IP per 10 minutes. The response never says whether
 * the password exists, only that it matched or did not.
 */
export async function POST(req: Request) {
  const ip = clientIp(req);
  const rl = await rateLimit("admin-login", ip, 5, 10 * 60 * 1000);
  if (!rl.ok) {
    return NextResponse.json(
      {
        error: `Too many attempts. Locked for ${rl.retryAfterSec}s.`,
        retryAfter: rl.retryAfterSec,
      },
      { status: 429, headers: { "retry-after": String(rl.retryAfterSec) } }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const password = (body as { password?: unknown })?.password;
  const ok = verifyAdminPassword(password);

  if (!ok) {
    // Small constant delay blunts online brute-force timing.
    await new Promise((r) => setTimeout(r, 120));
    return NextResponse.json({ error: "Invalid password." }, { status: 401 });
  }

  const res = NextResponse.json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, createSessionToken(), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 12 * 60 * 60,
  });
  return res;
}
