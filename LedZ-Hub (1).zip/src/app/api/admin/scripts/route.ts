import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isScriptStatus, sanitizeBadges } from "@/lib/script-status";
import type { ScriptsResponse } from "@/lib/hub-data";
import { guardAdmin, toHub } from "@/lib/admin-scripts";

export const runtime = "nodejs";

/**
 * GET /api/admin/scripts (authed)
 * Full list for the admin panel, in display order.
 */
export async function GET(req: Request) {
  const denied = await guardAdmin(req, "admin-read");
  if (denied) return denied;

  const rows = await db.script.findMany({
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
  });
  const payload: ScriptsResponse = {
    source: "next-runtime",
    total: rows.length,
    generated_at: new Date().toISOString(),
    scripts: rows.map(toHub),
  };
  return NextResponse.json(payload);
}

/**
 * POST /api/admin/scripts (authed)
 * Body: { title, code, category?, status?, badges? }
 */
export async function POST(req: Request) {
  const denied = await guardAdmin(req, "admin-write");
  if (denied) return denied;

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const title = typeof body.title === "string" ? body.title.trim() : "";
  const code = typeof body.code === "string" ? body.code.trim() : "";
  const category =
    typeof body.category === "string" && body.category.trim()
      ? body.category.trim()
      : "Uncategorized";
  const status = body.status ?? "working";
  // Unknown badge ids are dropped silently: the catalog is the contract.
  const badges = sanitizeBadges(body.badges);

  const errors: Record<string, string> = {};
  if (title.length < 2 || title.length > 120) {
    errors.title = "Title must be between 2 and 120 characters.";
  }
  if (code.length < 4 || code.length > 4000) {
    errors.code = "Loadstring must be between 4 and 4000 characters.";
  }
  if (category.length > 60) {
    errors.category = "Category must be 60 characters or fewer.";
  }
  if (!isScriptStatus(status)) {
    errors.status = "Unknown status.";
  }
  if (Object.keys(errors).length > 0) {
    return NextResponse.json({ error: "Validation failed.", errors }, { status: 400 });
  }

  const last = await db.script.findFirst({
    orderBy: { sortOrder: "desc" },
    select: { sortOrder: true },
  });

  const created = await db.script.create({
    data: {
      title,
      code,
      category,
      status: status as string,
      badges: JSON.stringify(badges),
      sortOrder: (last?.sortOrder ?? -1) + 1,
    },
  });

  return NextResponse.json({ script: toHub(created) }, { status: 201 });
}
