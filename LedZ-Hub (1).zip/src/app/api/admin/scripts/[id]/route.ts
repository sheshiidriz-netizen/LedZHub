import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isScriptStatus, sanitizeBadges } from "@/lib/script-status";
import { guardAdmin, toHub } from "@/lib/admin-scripts";

export const runtime = "nodejs";

/**
 * PATCH /api/admin/scripts/[id] (authed)
 * Body: any of { title?, code?, category?, status?, badges? }
 */
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const denied = await guardAdmin(req, "admin-write");
  if (denied) return denied;

  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const data: {
    title?: string;
    code?: string;
    category?: string;
    status?: string;
    badges?: string;
  } = {};
  const errors: Record<string, string> = {};

  if (body.title !== undefined) {
    const title = String(body.title).trim();
    if (title.length < 2 || title.length > 120) {
      errors.title = "Title must be between 2 and 120 characters.";
    } else {
      data.title = title;
    }
  }
  if (body.code !== undefined) {
    const code = String(body.code).trim();
    if (code.length < 4 || code.length > 4000) {
      errors.code = "Loadstring must be between 4 and 4000 characters.";
    } else {
      data.code = code;
    }
  }
  if (body.category !== undefined) {
    const category = String(body.category).trim() || "Uncategorized";
    if (category.length > 60) {
      errors.category = "Category must be 60 characters or fewer.";
    } else {
      data.category = category;
    }
  }
  if (body.status !== undefined) {
    if (!isScriptStatus(body.status)) {
      errors.status = "Unknown status.";
    } else {
      data.status = body.status;
    }
  }
  if (body.badges !== undefined) {
    // The catalog is the contract: unknown ids are dropped, order is canonical.
    data.badges = JSON.stringify(sanitizeBadges(body.badges));
  }

  if (Object.keys(errors).length > 0) {
    return NextResponse.json({ error: "Validation failed.", errors }, { status: 400 });
  }
  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }

  try {
    const updated = await db.script.update({ where: { id }, data });
    return NextResponse.json({ script: toHub(updated) });
  } catch {
    return NextResponse.json({ error: "Script not found." }, { status: 404 });
  }
}

/**
 * DELETE /api/admin/scripts/[id] (authed)
 */
export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const denied = await guardAdmin(req, "admin-write");
  if (denied) return denied;

  const { id } = await params;

  try {
    await db.script.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Script not found." }, { status: 404 });
  }
}
