# LedZ Hub — Void Edition

A premium, 3D-animated Roblox script hub. Black & red neon void aesthetic,
buttery motion, and a **Rust core** behind the API.

```
┌────────────────────────────┐        ┌─────────────────────────────┐
│  Next.js 16 web (:3000)    │  HTTP  │  Rust axum core (:8080)     │
│  React 19 · Tailwind 4     │ ─────► │  ledz-api · script database │
│  Three.js · framer-motion  │  JSON  │  key system · health probe  │
└────────────────────────────┘        └─────────────────────────────┘
```

The frontend calls its own `/api/*` route handlers. When the environment
variable `LEDZ_API_URL` points at the Rust core, those handlers proxy to it
(2 s timeout, 30 s revalidation) — otherwise the Next.js runtime serves the
identical contract from `src/lib/hub-data.ts`. **The UI never breaks**, and
the footer badge tells you which backend is live:

- `LEDZ-API · RUST CORE CONNECTED` — served by Rust
- `NEXT RUNTIME · RUST CORE READY` — local fallback

## Quick start (frontend only)

```bash
bun install
bun run dev        # → http://localhost:3000
```

## Full stack (Rust core + web)

```bash
# Terminal 1 — the Rust core
cd services/ledz-api && cargo run --release

# Terminal 2 — the web app, wired to the core
LEDZ_API_URL=http://localhost:8080 bun run dev
```

Or everything in containers:

```bash
docker compose up --build
```

## API contract

| Endpoint (web)  | Upstream (Rust)  | Payload                                                |
| --------------- | ---------------- | ------------------------------------------------------ |
| `GET /api/scripts` | `/api/scripts` | `{ source, total, generated_at, scripts: [{ id, title, category, code }] }` |
| `GET /api/key`     | `/api/key`     | `{ source, label, key, status, active, updated_at }`   |
| `GET /api/health`  | `/api/health`  | `{ status, service, version, upstream }` (web) / `{ uptime_secs }` (Rust) |

## Experience

- **Void intro** — 3D Z-cube with orbit rings, staged boot sequence,
  canvas particle explosion with double shockwave, blur-in welcome.
  Plays once per session; `?intro=0` skips, `?intro=force` replays.
- **3D background** — Three.js additive nebula (1 300 red/white particles)
  with drifting wireframe geometry, pointer parallax and scroll drift.
  Static single frame under `prefers-reduced-motion`; hard-fails to flat.
- **Motion discipline** — one UI ease `cubic-bezier(.2,.8,.2,1)`, one
  entrance ease `cubic-bezier(.22,1,.36,1)`; hover 150/120 ms, press 90 ms,
  tab pill 240 ms. Transform & opacity only — nothing else animates.
- **Script cards** — pointer-lerped 3D tilt with cursor glare, HUD corner
  brackets, shine sweep over the loadstring, glyph-morph copy feedback,
  layout-animated filtering.
- **Key page** — rotating conic-gradient frame, scanline sweep, numbered
  activation steps.
- **3D page slider** — both pages ride a 1 400 px perspective track; the
  departing page swings away with `rotateY`.

## Keyboard

| Key         | Action                          |
| ----------- | ------------------------------- |
| `/`         | Focus script search             |
| `Esc`       | Clear search                    |
| `←` / `→`   | Switch tabs (when tabs focused) |
| `Tab`       | Reach every control             |

## Structure

```
src/app/                 App router — / , /api/{scripts,key,health}
src/components/hub/      Void UI: splash, 3D scene, cards, key system…
src/hooks/               use-tilt (3D tilt), use-count-up
src/lib/                 hub data (contract source of truth), motion tokens
services/ledz-api/       Rust axum core + Dockerfile
docker-compose.yml       web + core, production wiring
```
