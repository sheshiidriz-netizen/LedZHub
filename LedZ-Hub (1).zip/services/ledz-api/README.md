# LedZ Rust Core (`ledz-api`)

The production backend for **LedZ Hub — Void Edition**. A single static
binary built with **axum + tokio** that serves the script database and the
universal key system with sub-millisecond responses.

## Endpoints

| Endpoint       | Description                  | Response fields                                        |
| -------------- | ---------------------------- | ------------------------------------------------------ |
| `GET /api/scripts` | Full script database      | `source`, `total`, `generated_at`, `scripts[]`          |
| `GET /api/key`     | Universal activation key  | `source`, `label`, `key`, `status`, `active`, `updated_at` |
| `GET /api/health`  | Liveness + uptime probe   | `status`, `service`, `version`, `uptime_secs`           |

Every payload sets `"source": "rust-core"` so the frontend badge can show
**LEDZ-API · RUST CORE CONNECTED**.

## Run locally

```bash
cd services/ledz-api
cargo run --release
# → listening on http://0.0.0.0:8080

curl http://localhost:8080/api/scripts | head -c 400
curl http://localhost:8080/api/key
curl http://localhost:8080/api/health
```

Then point the web app at it:

```bash
LEDZ_API_URL=http://localhost:8080 # env for the Next.js server
```

## Run with Docker

```bash
docker compose up --build   # from the repo root — web + core together
```

Or standalone:

```bash
docker build -t ledz-api ./services/ledz-api
docker run -p 8080:8080 ledz-api
```

## Design notes

- **Static data, zero locks.** The database is a `&'static [Script]` slice;
  responses are serialized straight from static memory.
- **No chrono.** Timestamps are assembled from `SystemTime` to keep the
  dependency tree (and binary) tiny.
- **Release profile** uses LTO, one codegen unit and symbol stripping —
  the release binary is a few megabytes.
- **CORS** allows `http://localhost:3000` for development. Set your real
  origin before deploying.
