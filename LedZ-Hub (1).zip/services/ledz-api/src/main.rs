//! LedZ Hub — Rust Core API (Void Edition)
//!
//! The production backend for the LedZ Hub frontend. Serves the script
//! database and the universal key system behind a thin, fast axum router.
//!
//! Contract (identical to the Next.js runtime fallback):
//!   GET /api/scripts                 → full catalog { source, total, generated_at, scripts[] }
//!   GET /api/scripts/search?q=&limit= → ranked search over the catalog
//!   GET /api/key                     → { source, label, key, status, active, updated_at }
//!   GET /api/health                  → { status, service, version, uptime_secs }

use std::sync::OnceLock;
use std::time::Instant;

use axum::{
    extract::Query,
    http::{HeaderValue, Method},
    routing::get,
    Json, Router,
};
use serde::{Deserialize, Serialize};

const SERVICE: &str = "ledz-api";
const VERSION: &str = "2.1.0-void";
const SOURCE: &str = "rust-core";

#[derive(Clone, Copy, Serialize)]
struct Script {
    id: &'static str,
    title: &'static str,
    category: &'static str,
    code: &'static str,
}

#[derive(Serialize)]
struct ScriptsResponse {
    source: &'static str,
    total: usize,
    generated_at: String,
    scripts: Vec<Script>,
}

#[derive(Serialize)]
struct KeyResponse {
    source: &'static str,
    label: &'static str,
    key: &'static str,
    status: &'static str,
    active: bool,
    updated_at: String,
}

#[derive(Serialize)]
struct HealthResponse {
    status: &'static str,
    service: &'static str,
    version: &'static str,
    uptime_secs: u128,
}

/// The script database. Codes are kept verbatim — executors copy them 1:1.
static SCRIPTS: &[Script] = &[
    Script {
        id: "naval-warfare",
        title: "Naval Warfare",
        category: "Combat",
        code: r#"loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/navalwarfareLedZ/main/navalwarfere"))()"#,
    },
    Script {
        id: "ninja-legends",
        title: "Ninja Legends",
        category: "Farming",
        code: r#"pcall(loadstring(game:HttpGet("https://raw.githubusercontent.com/sheshiidriz-netizen/NinjaLegends-/main/InfMoney")))"#,
    },
    Script {
        id: "mvsd",
        title: "Murderers VS Sheriffs DUELS",
        category: "PvP",
        code: r#"pcall(loadstring(game:HttpGet("https://raw.githubusercontent.com/sheshiidriz-netizen/LEDZ/main/MvsD")))"#,
    },
    Script {
        id: "fight-in-a-prison",
        title: "Fight In A Prison",
        category: "Action",
        code: r#"loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/fightinaprison/refs/heads/main/ledzfightinaprison"))()"#,
    },
    Script {
        id: "age-evolution-tycoon",
        title: "Age Evolution Tycoon",
        category: "Tycoon",
        code: r#"pcall(loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/AgeEvelutionTycoon/main/AgeEvelutionTycoon")))"#,
    },
    Script {
        id: "millionaire-tycoon",
        title: "Millionaire Tycoon",
        category: "Tycoon",
        code: r#"pcall(loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/MillonareTycoon/main/Tycoon")))"#,
    },
    Script {
        id: "blox-strike",
        title: "Blox Strike",
        category: "FPS",
        code: r#"loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/bloxstrike/refs/heads/main/ledz"))()"#,
    },
    Script {
        id: "mm2-premium",
        title: "Murder Mystery 2 Premium",
        category: "Survival",
        code: r#"loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/murdermystery2/refs/heads/main/LedZPremium"))()"#,
    },
    Script {
        id: "find-the-needle",
        title: "Find The Needle",
        category: "Casual",
        code: r#"loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/findtheneedle/refs/heads/main/ledz"))()"#,
    },
    Script {
        id: "soccer-touch-football",
        title: "Soccer Touch Football",
        category: "Sports",
        code: r#"loadstring(game:HttpGet("https://raw.githubusercontent.com/leodoscripts/soccertouchfootball/refs/heads/main/ledz"))()"#,
    },
];

/// Search-ready copy of the catalog. Lowercase keys and title initials
/// are computed once, on the first search, instead of allocating strings
/// per script on every request: the request path stays allocation-free
/// until the response is serialized.
struct SearchEntry {
    script: Script,
    title_lower: String,
    title_initials: String,
    category_lower: String,
}

static SEARCH_INDEX: OnceLock<Vec<SearchEntry>> = OnceLock::new();

fn search_index() -> &'static [SearchEntry] {
    SEARCH_INDEX.get_or_init(|| {
        SCRIPTS
            .iter()
            .map(|s| SearchEntry {
                script: *s,
                title_lower: s.title.to_lowercase(),
                title_initials: s
                    .title
                    .split_whitespace()
                    .filter_map(|w| w.chars().next())
                    .flat_map(|c| c.to_lowercase())
                    .collect(),
                category_lower: s.category.to_lowercase(),
            })
            .collect()
    })
}

#[derive(Clone)]
struct AppState {
    started: Instant,
}

#[derive(Deserialize)]
struct SearchParams {
    q: Option<String>,
    limit: Option<usize>,
}

async fn scripts() -> Json<ScriptsResponse> {
    Json(ScriptsResponse {
        source: SOURCE,
        total: SCRIPTS.len(),
        generated_at: chrono_now(),
        scripts: SCRIPTS.to_vec(),
    })
}

/// Ranked search over the script database, from memory. Scoring mirrors
/// the frontend rankScripts order exactly, so both tiers agree:
/// title prefix → title word prefix → title acronym ("mm2" finds
/// "Murder Mystery 2") → title substring → category.
/// The index is built once and shared by every request.
async fn scripts_search(Query(params): Query<SearchParams>) -> Json<ScriptsResponse> {
    let q = params.q.unwrap_or_default().trim().to_lowercase();
    let limit = params.limit.unwrap_or(20).clamp(1, 50);

    if q.is_empty() {
        return Json(ScriptsResponse {
            source: SOURCE,
            total: 0,
            generated_at: chrono_now(),
            scripts: Vec::new(),
        });
    }

    let mut scored: Vec<(u8, &SearchEntry)> = search_index()
        .iter()
        .filter_map(|e| {
            let score = if e.title_lower.starts_with(&q) {
                0u8
            } else if e
                .title_lower
                .split_whitespace()
                .any(|w| w.starts_with(&q))
            {
                1
            } else if q.len() >= 2 && e.title_initials.starts_with(&q) {
                2
            } else if e.title_lower.contains(&q) {
                3
            } else if e.category_lower.starts_with(&q) {
                4
            } else if e.category_lower.contains(&q) {
                5
            } else {
                return None;
            };
            Some((score, e))
        })
        .collect();

    scored.sort_by(|a, b| {
        a.0.cmp(&b.0)
            .then_with(|| a.1.script.title.cmp(b.1.script.title))
    });
    scored.truncate(limit);

    let matched = scored.len();
    Json(ScriptsResponse {
        source: SOURCE,
        total: matched,
        generated_at: chrono_now(),
        scripts: scored.into_iter().map(|(_, e)| e.script).collect(),
    })
}

async fn key() -> Json<KeyResponse> {
    Json(KeyResponse {
        source: SOURCE,
        label: "Global Script Key",
        key: "LedZKey",
        status: "Verified Universal Access",
        active: true,
        updated_at: chrono_now(),
    })
}

async fn health(axum::extract::State(state): axum::extract::State<AppState>) -> Json<HealthResponse> {
    Json(HealthResponse {
        status: "ok",
        service: SERVICE,
        version: VERSION,
        uptime_secs: state.started.elapsed().as_secs(),
    })
}

/// RFC-3339-ish UTC timestamp without pulling in a chrono dependency.
fn chrono_now() -> String {
    let secs = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    format!("1970-01-01T00:00:00Z+{secs}")
}

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "ledz_api=info,tower_http=info".into()),
        )
        .init();

    let port = std::env::var("LEDZ_API_PORT").unwrap_or_else(|_| "8080".to_string());
    let addr = format!("0.0.0.0:{port}");

    let state = AppState {
        started: Instant::now(),
    };

    // Permissive CORS for development; tighten to your origin in production.
    let cors = tower_http::cors::CorsLayer::new()
        .allow_origin("http://localhost:3000".parse::<HeaderValue>().unwrap())
        .allow_methods([Method::GET]);

    let app = Router::new()
        .route("/api/scripts", get(scripts))
        .route("/api/scripts/search", get(scripts_search))
        .route("/api/key", get(key))
        .route("/api/health", get(health))
        .layer(cors)
        .layer(tower_http::trace::TraceLayer::new_for_http())
        .with_state(state);

    let listener = tokio::net::TcpListener::bind(&addr)
        .await
        .expect("failed to bind LEDZ_API port");

    tracing::info!("LedZ Rust Core v{VERSION} listening on http://{addr}");

    axum::serve(listener, app)
        .await
        .expect("server error");
}
